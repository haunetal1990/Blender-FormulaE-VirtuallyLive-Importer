# -*- coding: utf-8 -*-
bl_info = {
    "name": "FE powered by Virtually Live Importer",
    "author": "haunetal1990",
    "version": (0, 80),
    "blender": (3, 6, 0),
    "location": "File > Import > FE powered by Virtually Live (.assets.resS)",
    "description": "Imports a complete track (level, meshes, materials, textures, sky, racing line) "
                   "directly from the Unity files of Formula E powered by Virtually Live",
    "category": "Import-Export",
}

import os
import re
import sys
import time
import traceback

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

from .vlivecore import unity as U
from .vlivecore import scene as S
from .vlivecore import textures as T
from .vlivecore import worker as W

TRACK_NAMES = {
    'Argentina2017': 'Buenos Aires', 'Berlin2017': 'Berlin', 'HongKong': 'Hong Kong', 'Marrakesh': 'Marrakesh',
    'Mexico2017': 'Mexico City', 'Monaco': 'Monaco', 'Montreal': 'Montreal', 'NewYork': 'New York',
    'Paris2017': 'Paris',
}
# levels without a racing line (menus / VR rooms)
SCENE_NAMES = {'level5': 'Pit Garage', 'level8': 'Pub', 'level3': 'Menu Lobby (Buenos Aires)'}
SCENE_HINTS = {'level3': 'level3 is the menu lobby - most of the city is switched off there. '
                         'The Buenos Aires race track is sharedassets12.assets (level12).'}


def _documents_dir():
    docs = os.path.join(os.path.expanduser('~'), 'Documents')
    return docs if os.path.isdir(docs) else os.path.expanduser('~')


def _writable(d):
    try:
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, '.write_test')
        with open(p, 'w') as f:
            f.write('x')
        os.remove(p)
        return True
    except Exception:
        return False


def resolve_target(path):
    """Selected file -> (VLive_Data folder, scene file)"""
    d = os.path.dirname(os.path.abspath(path))
    fn = os.path.basename(path)
    m = re.match(r'^level(\d+)(\.resS)?$', fn, re.I)
    if m:
        return d, 'level%s' % m.group(1)
    m = re.match(r'^sharedassets(\d+)\.(assets(\.resS)?|resource)$', fn, re.I)
    if m:
        return d, 'level%s' % m.group(1)
    if fn.lower().startswith('resources.assets'):
        return d, 'resources.assets'
    return d, fn


def _prefs(context):
    try:
        return context.preferences.addons[__name__].preferences
    except Exception:
        return None


class VLIVE_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    lod0_only: BoolProperty(name="Highest detail level only (LOD0)", default=True)
    inactive_mode: EnumProperty(
        name="Objects switched off in the scene",
        items=[('HIDDEN', "Hidden collection",
                 "Import them into an excluded collection, grouped by their Unity parent "
                 "(trees, grandstands, pit boxes ... that the game switches on at runtime)"),
               ('SKIP', "Skip", "Do not import them (faster)"),
               ('VISIBLE', "Visible", "Import them like everything else")],
        default='HIDDEN')
    skip_shadow_only: BoolProperty(name="Skip shadow-only renderers", default=True)
    import_normals: BoolProperty(name="Use the game's normals", default=True)
    include_prefabs: BoolProperty(name="Also import prefabs of sharedassetsN",
                                  description="e.g. the cars in sharedassets11", default=False)
    vertex_color_strength: FloatProperty(name="Vertex colour (buildings)", default=1.0, min=0.0, max=1.0,
                                         description="1.0 = as in the game")
    import_sky: BoolProperty(name="Sky (reflections + light)", default=True,
                             description="The level's sky as HDR world background")
    sky_strength: FloatProperty(name="Sky strength", default=1.0, min=0.0, soft_max=4.0)
    terrain_tile: FloatProperty(name="Terrain texture tile size (m)", default=15.0, min=0.5, soft_max=100.0,
                                description="Distingo terrain meshes: size of one texture tile in metres "
                                            "(the game sets it at runtime)")
    last_dir: StringProperty(name="Last folder", default="", options={'HIDDEN'})
    workers: IntProperty(name="Texture decoding processes", default=0, min=0, max=32,
                         description="0 = automatic (number of CPU cores - 1)")

    def draw(self, context):
        l = self.layout
        c = l.column()
        c.label(text="Advanced options (the import dialog only shows the common ones)")
        c.prop(self, 'lod0_only'); c.prop(self, 'inactive_mode'); c.prop(self, 'skip_shadow_only')
        c.prop(self, 'import_normals'); c.prop(self, 'include_prefabs')
        c.prop(self, 'vertex_color_strength'); c.prop(self, 'import_sky'); c.prop(self, 'sky_strength')
        c.prop(self, 'terrain_tile'); c.prop(self, 'workers')


class IMPORT_OT_vlive_track(bpy.types.Operator, ImportHelper):
    """Import a track from Formula E powered by Virtually Live"""
    bl_idname = "import_scene.vlive_track"
    bl_label = "Import"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".resS"
    # sharedassets12 (Buenos Aires race) has no .resS -> list it explicitly.  Blender compares each
    # ';' pattern with at most 15 characters (issue #92610), so the short form '*s12.assets' is used.
    filter_glob: StringProperty(default="*.assets.resS;*s12.assets", options={'HIDDEN'})

    texture_storage: EnumProperty(
        name="Textures",
        items=[('GAME', "Folder next to game files",
                "Decoded textures are kept in VLive_Data/VLive_Blender_Textures - the next import is much faster"),
               ('TEMP', "Temporary (deleted on exit)",
                "Textures are packed into the .blend file; the temporary files are deleted when Blender closes")],
        default='GAME')
    max_tex: EnumProperty(name="Quality",
                          items=[('0', "Original", "Full resolution"), ('2048', "Max 2048", ""),
                                 ('1024', "Max 1024", "Faster, less memory"), ('512', "Max 512", "Fastest")],
                          default='0')
    import_paths: BoolProperty(name="Racing line + pit lane", default=True,
                               description="Waypoints of the game's cars and the pit lane as curves")

    def draw(self, context):
        l = self.layout
        l.prop(self, 'texture_storage')
        l.prop(self, 'max_tex')
        l.prop(self, 'import_paths')
        l.label(text="More options: Preferences > Add-ons", icon='INFO')

    def invoke(self, context, event):
        # file name field shows the pattern; folder = last used VLive_Data
        pr = _prefs(context)
        last = getattr(pr, 'last_dir', '') if pr else ''
        self.filepath = os.path.join(last, '*.assets.resS') if last and os.path.isdir(last) else '*.assets.resS'
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    # ------------------------------------------------------------------
    def execute(self, context):
        from . import build as Bd
        t_start = time.time()
        wm = context.window_manager
        pr = _prefs(context)
        get = (lambda k, d: getattr(pr, k, d)) if pr else (lambda k, d: d)

        def log(msg):
            print('[VLive] ' + msg)
            sys.stdout.flush()

        def progress(f, msg=None):
            try:
                wm.progress_update(int(max(0.0, min(1.0, f)) * 100))
            except Exception:
                pass
            if msg:
                log(msg)

        if '*' in os.path.basename(self.filepath):
            self.report({'ERROR'}, "Please select a sharedassetsN.assets.resS file")
            return {'CANCELLED'}
        data_dir, target = resolve_target(self.filepath)
        if not os.path.isfile(os.path.join(data_dir, target)):
            self.report({'ERROR'}, "File missing: %s (in %s). Please pick a file directly inside VLive_Data."
                        % (target, data_dir))
            return {'CANCELLED'}

        pack = False
        if self.texture_storage == 'TEMP':
            cache = os.path.join(bpy.app.tempdir or _documents_dir(), 'VLive_Textures')
            pack = True
        else:
            cache = os.path.join(data_dir, 'VLive_Blender_Textures')
            if not _writable(cache):
                alt = os.path.join(_documents_dir(), 'VLive_Blender_Textures')
                log('%s is not writable -> using %s' % (cache, alt))
                cache = alt
        if not _writable(cache):
            cache = os.path.join(bpy.app.tempdir or _documents_dir(), 'VLive_Textures')
            pack = True

        Bd.LOD0_ONLY = get('lod0_only', True)
        Bd.INACTIVE_MODE = get('inactive_mode', 'HIDDEN')
        Bd.SKIP_SHADOW_ONLY = get('skip_shadow_only', True)
        Bd.VERTEX_COLOR_STRENGTH = get('vertex_color_strength', 1.0)
        import_sky = get('import_sky', True)
        Bd.IMPORT_SKY = import_sky
        Bd.SKY_STRENGTH = get('sky_strength', 1.0)
        Bd.IMPORT_NORMALS = get('import_normals', True)
        S.SPLAT_TILE_M = get('terrain_tile', 15.0)
        workers = get('workers', 0) or max(1, min(8, (os.cpu_count() or 2) - 1))

        env = U.Environment(data_dir)
        Bd.TIMING.clear()
        wm.progress_begin(0, 100)
        total = 0
        warnings = []
        try:
            sf = env.get(target)
            if sf is None:
                self.report({'ERROR'}, "%s could not be read" % target)
                return {'CANCELLED'}
            log('Reading %s (%d objects) ...' % (target, len(sf.objects)))
            t_ph = time.perf_counter()
            scenes = [S.collect(env, sf, target, log=log)]
            if get('include_prefabs', False):
                m = re.match(r'level(\d+)$', target)
                sa = env.get('sharedassets%s.assets' % m.group(1)) if m else None
                if sa is not None:
                    scenes.append(S.collect(env, sa, sa.name + ' (prefabs)', log=log))
            if all(sd.stats['renderer'] == 0 for sd in scenes):
                self.report({'WARNING'}, "%s contains no visible geometry (menu or loading scene)" % target)
                return {'CANCELLED'}

            Bd.TIMING['read scene'] = time.perf_counter() - t_ph
            # track detection (racing line) -> collection name
            main = scenes[0]
            t_ph = time.perf_counter()
            paths = S.find_paths(env, main, log=log)
            Bd.TIMING['racing line'] = time.perf_counter() - t_ph
            track = ''
            for p in paths:
                if p['kind'] == 'racing_line':
                    key = re.sub(r'_Option\w+$', '', p['name'][len('Waypoints_'):])
                    track = TRACK_NAMES.get(key, key)
                    break
            if target in SCENE_HINTS:
                log('NOTE: ' + SCENE_HINTS[target])
                warnings.append(SCENE_HINTS[target])
            if target in SCENE_NAMES:
                main.name = '%s (%s)' % (SCENE_NAMES[target], target)
                log('Scene: %s' % SCENE_NAMES[target])
            elif track:
                main.name = '%s (%s)' % (track, target)
                log('Track: %s' % track)
            for sd in scenes:
                log('%s: %d renderers, %d materials' % (sd.name, sd.stats['renderer'], len(sd.materials)))

            # textures: decode everything in parallel first
            tc = T.TextureCache(env, cache, max_size=int(self.max_tex), log=log)
            used = set()
            for sd in scenes:
                for nd in sd.nodes:
                    if Bd.node_filter(nd):
                        used.update(k for k in nd.get('materials', []) if k)
            mats = [sd.materials[k] for sd in scenes for k in used if k in sd.materials]
            t_ph = time.perf_counter()
            jobs = W.plan_jobs(mats, tc)
            if jobs:
                log('Decoding %d textures with %d processes ...' % (len(jobs), workers))
                t0 = time.time()
                res = W.decode_parallel(jobs, data_dir, cache, int(self.max_tex), workers,
                                        progress=lambda f, m: progress(0.6 * f, m), log=log)
                if res is not None:
                    objs = {}
                    for sd in scenes:
                        for d in sd.materials.values():
                            for t in d.get('textures', {}).values():
                                objs[(t['obj'].sf.name, t['obj'].path_id)] = t['obj']
                    for (kind, fn, pid, normal), (r, fails) in res.items():
                        o = objs.get((fn, pid))
                        if o is not None:
                            tc.accept(kind, o, normal, r, fails)
                    log('Textures done in %.0f s' % (time.time() - t0))
                # (if the pool is not usable the textures are decoded on demand during the build)
            Bd.TIMING['textures'] = time.perf_counter() - t_ph

            for sd in scenes:
                n, nsh = Bd.import_scene(sd, tc, S.mesh_arrays, pack=pack,
                                         progress=lambda f, m: progress(0.6 + 0.35 * f, m), log=log)
                total += n
                log('%s: %d objects imported' % (sd.name, n))
                if sd is main and self.import_paths:
                    if paths:
                        Bd.create_paths(paths, getattr(sd, 'blender_collection', context.scene.collection),
                                        sd.name)
                    elif target not in SCENE_NAMES:
                        warnings.append('no racing line found for this level')
                if import_sky and sd.skybox:
                    t_ph = time.perf_counter()
                    progress(0.97, 'Computing sky ...')
                    p = tc.skybox(sd.skybox['cube'], sd.skybox['rotation'], sd.name)
                    if Bd.setup_world(p, sd.skybox, sd.name):
                        if pack and bpy.context.scene.world:
                            for n_ in bpy.context.scene.world.node_tree.nodes:
                                if getattr(n_, 'image', None) is not None and not n_.image.packed_file:
                                    n_.image.pack()
                        log('Sky: %s' % sd.skybox['material'])
                    Bd.TIMING['sky'] = time.perf_counter() - t_ph

            if pr is not None:
                try:
                    pr.last_dir = data_dir
                except Exception:
                    pass
            for area in context.screen.areas if context.screen else []:
                if area.type == 'VIEW_3D':
                    for sp in area.spaces:
                        if sp.type == 'VIEW_3D':
                            sp.clip_end = max(sp.clip_end, 20000.0)

            missing = sorted(env.missing)
            if missing:
                warnings.append('missing files: ' + ', '.join(missing))
            mm = sum(sd.stats['mesh_missing'] for sd in scenes)
            if mm:
                warnings.append('%d meshes not found' % mm)
            if tc.failed:
                warnings.append('%d textures unreadable (e.g. %s)' % (len(tc.failed), tc.failed[0]))
                for f in tc.failed:
                    log('  ! texture: ' + f)
            dt = time.time() - t_start
            tm = Bd.TIMING
            order = ['read scene', 'racing line', 'textures', 'read meshes', 'geometry prep', 'blender meshes',
                     'normals check', 'custom normals', 'materials', 'sky']
            log('Timing: ' + ' | '.join('%s %.1f s' % (k, tm[k]) for k in order if k in tm) +
                ' | normals skipped %d / custom %d' % (tm.get('normals skipped', 0), tm.get('normals custom', 0)))
            log('Done: %d objects in %.0f s. Textures: %s' % (total, dt, cache))
            if warnings:
                for w in warnings:
                    log('WARNING: ' + w)
                self.report({'WARNING'}, '%d objects imported in %.0f s. %s (details: Window > Toggle System Console)'
                            % (total, dt, ' | '.join(warnings)))
            else:
                self.report({'INFO'}, '%s: %d objects imported in %.0f s' % (main.name, total, dt))
        except Exception as ex:
            traceback.print_exc()
            self.report({'ERROR'}, 'Import failed: %s (details: Window > Toggle System Console)' % ex)
            return {'CANCELLED'}
        finally:
            wm.progress_end()
            env.close_all()
        return {'FINISHED'}


def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_vlive_track.bl_idname, text="FE powered by Virtually Live (.assets.resS)")


classes = (VLIVE_AddonPreferences, IMPORT_OT_vlive_track)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
