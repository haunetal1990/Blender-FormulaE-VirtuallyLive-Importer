# -*- coding: utf-8 -*-
"""Textur-Decoder in reinem numpy (ohne Pillow): BC1/BC3/BC4/BC5/BC7/BC6H und unkomprimierte Unity-Formate.
Ergebnis: numpy-Array (H, W, 4) uint8 (bzw. float32 fuer BC6H/Half/Float), Zeilen in Speicherreihenfolge
(bei Unity = untere Bildzeile zuerst)."""
import numpy as np

# ---------------------------------------------------------------- Hilfen
def _blocks_to_image(px, w, h, ch=4):
    """px: (by*bx, 16, ch) -> (h, w, ch)"""
    bx, by = (w + 3) // 4, (h + 3) // 4
    img = px.reshape(by, bx, 4, 4, ch).transpose(0, 2, 1, 3, 4).reshape(by * 4, bx * 4, ch)
    return img[:h, :w]


def _bc_size(w, h, bpb):
    return ((w + 3) // 4) * ((h + 3) // 4) * bpb


def _expand565(c):
    r = (c >> 11) & 31
    g = (c >> 5) & 63
    b = c & 31
    return np.stack([(r << 3) | (r >> 2), (g << 2) | (g >> 4), (b << 3) | (b >> 2)], -1).astype(np.int32)


def _bc1_color(blk8, punch_through=True):
    """blk8: (N, 8) uint8 -> (N, 16, 4) uint8"""
    N = len(blk8)
    c = blk8[:, :4].copy().view('<u2').astype(np.int32)        # (N,2)
    c0, c1 = c[:, 0], c[:, 1]
    e0, e1 = _expand565(c0), _expand565(c1)
    pal = np.empty((N, 4, 4), np.uint8)
    pal[:, 0, :3] = e0
    pal[:, 1, :3] = e1
    pal[:, :, 3] = 255
    if punch_through:
        four = c0 > c1
        f = four[:, None]
        pal[:, 2, :3] = np.where(f, (2 * e0 + e1) // 3, (e0 + e1) // 2)
        pal[:, 3, :3] = np.where(f, (e0 + 2 * e1) // 3, 0)
        pal[:, 3, 3] = np.where(four, 255, 0)
    else:
        pal[:, 2, :3] = (2 * e0 + e1) // 3
        pal[:, 3, :3] = (e0 + 2 * e1) // 3
    idx = blk8[:, 4:8].copy().view('<u4')[:, 0]
    sel = ((idx[:, None] >> (2 * np.arange(16, dtype=np.uint32))) & 3).astype(np.intp)
    return pal[np.arange(N)[:, None], sel]


def _bc4_channel(blk8):
    """blk8: (N, 8) -> (N, 16) uint8 (BC3-Alpha / BC4)"""
    N = len(blk8)
    a0 = blk8[:, 0].astype(np.int32)
    a1 = blk8[:, 1].astype(np.int32)
    six = a0 > a1
    pal = np.empty((N, 8), np.uint8)
    pal[:, 0], pal[:, 1] = a0, a1
    for i in range(1, 7):
        alt = ((5 - i) * a0 + i * a1) // 5 if i < 5 else (0 if i == 5 else 255)
        pal[:, i + 1] = np.where(six, ((7 - i) * a0 + i * a1) // 7, alt)
    b = np.zeros((N, 8), np.uint8)
    b[:, :6] = blk8[:, 2:8]
    bits = b.view('<u8')[:, 0]
    sel = ((bits[:, None] >> (3 * np.arange(16, dtype=np.uint64))) & np.uint64(7)).astype(np.intp)
    return pal[np.arange(N)[:, None], sel]


def decode_bc1(data, w, h):
    b = np.frombuffer(data, np.uint8, _bc_size(w, h, 8)).reshape(-1, 8)
    return _blocks_to_image(_bc1_color(b), w, h)


def decode_bc3(data, w, h):
    b = np.frombuffer(data, np.uint8, _bc_size(w, h, 16)).reshape(-1, 16)
    px = _bc1_color(b[:, 8:], punch_through=False)
    px[:, :, 3] = _bc4_channel(b[:, :8])
    return _blocks_to_image(px, w, h)


def decode_bc4(data, w, h):
    b = np.frombuffer(data, np.uint8, _bc_size(w, h, 8)).reshape(-1, 8)
    r = _bc4_channel(b)
    px = np.stack([r, r, r, np.full_like(r, 255)], -1)
    return _blocks_to_image(px, w, h)


def decode_bc5(data, w, h):
    b = np.frombuffer(data, np.uint8, _bc_size(w, h, 16)).reshape(-1, 16)
    r = _bc4_channel(b[:, :8])
    g = _bc4_channel(b[:, 8:])
    px = np.stack([r, g, np.zeros_like(r), np.full_like(r, 255)], -1)
    return _blocks_to_image(px, w, h)


# ---------------------------------------------------------------- BPTC Tabellen
_P2 = [0xcccc, 0x8888, 0xeeee, 0xecc8, 0xc880, 0xfeec, 0xfec8, 0xec80, 0xc800, 0xffec, 0xfe80, 0xe800, 0xffe8, 0xff00,
       0xfff0, 0xf000, 0xf710, 0x008e, 0x7100, 0x08ce, 0x008c, 0x7310, 0x3100, 0x8cce, 0x088c, 0x3110, 0x6666, 0x366c,
       0x17e8, 0x0ff0, 0x718e, 0x399c, 0xaaaa, 0xf0f0, 0x5a5a, 0x33cc, 0x3c3c, 0x55aa, 0x9696, 0xa55a, 0x73ce, 0x13c8,
       0x324c, 0x3bdc, 0x6996, 0xc33c, 0x9966, 0x0660, 0x0272, 0x04e4, 0x4e40, 0x2720, 0xc936, 0x936c, 0x39c6, 0x639c,
       0x9336, 0x9cc6, 0x817e, 0xe718, 0xccf0, 0x0fcc, 0x7744, 0xee22]
_A2 = [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 2, 8, 2, 2, 8, 8, 15, 2, 8, 2, 2, 8, 8, 2, 2,
       15, 15, 6, 8, 2, 8, 15, 15, 2, 8, 2, 2, 2, 15, 15, 6, 6, 2, 6, 8, 15, 15, 2, 2, 15, 15, 15, 15, 15, 2, 2, 15]
_P3 = [0xaa685050, 0x6a5a5040, 0x5a5a4200, 0x5450a0a8, 0xa5a50000, 0xa0a05050, 0x5555a0a0, 0x5a5a5050, 0xaa550000,
       0xaa555500, 0xaaaa5500, 0x90909090, 0x94949494, 0xa4a4a4a4, 0xa9a59450, 0x2a0a4250, 0xa5945040, 0x0a425054,
       0xa5a5a500, 0x55a0a0a0, 0xa8a85454, 0x6a6a4040, 0xa4a45000, 0x1a1a0500, 0x0050a4a4, 0xaaa59090, 0x14696914,
       0x69691400, 0xa08585a0, 0xaa821414, 0x50a4a450, 0x6a5a0200, 0xa9a58000, 0x5090a0a8, 0xa8a09050, 0x24242424,
       0x00aa5500, 0x24924924, 0x24499224, 0x50a50a50, 0x500aa550, 0xaaaa4444, 0x66660000, 0xa5a0a5a0, 0x50a050a0,
       0x69286928, 0x44aaaa44, 0x66666600, 0xaa444444, 0x54a854a8, 0x95809580, 0x96969600, 0xa85454a8, 0x80959580,
       0xaa141414, 0x96960000, 0xaaaa1414, 0xa05050a0, 0xa0a5a5a0, 0x96000000, 0x40804080, 0xa9a8a9a8, 0xaaaaaa44,
       0x2a4a5254]
_A3 = [[3, 3, 15, 15, 8, 3, 15, 15, 8, 8, 6, 6, 6, 5, 3, 3, 3, 3, 8, 15, 3, 3, 6, 10, 5, 8, 8, 6, 8, 5, 15, 15,
        8, 15, 3, 5, 6, 10, 8, 15, 15, 3, 15, 5, 15, 15, 15, 15, 3, 15, 5, 5, 5, 8, 5, 10, 5, 10, 8, 13, 15, 12, 3, 3],
       [15, 8, 8, 3, 15, 15, 3, 8, 15, 15, 15, 15, 15, 15, 15, 8, 15, 8, 15, 3, 15, 8, 15, 8, 3, 15, 6, 10, 15, 15, 10, 8,
        15, 3, 15, 10, 10, 8, 9, 10, 6, 15, 8, 15, 3, 6, 6, 8, 15, 3, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 3, 15, 15, 8]]
_FACT = {2: np.array([0, 21, 43, 64]), 3: np.array([0, 9, 18, 27, 37, 46, 55, 64]),
         4: np.array([0, 4, 9, 13, 17, 21, 26, 30, 34, 38, 43, 47, 51, 55, 60, 64])}


def _subset_tables(nsub):
    """-> subset[part, pix], anchor[part, pix] (bool)"""
    sub = np.zeros((64, 16), np.int64)
    anc = np.zeros((64, 16), bool)
    anc[:, 0] = True
    for p in range(64):
        for i in range(16):
            if nsub == 2:
                s = (_P2[p] >> i) & 1
                sub[p, i] = s
                if s and _A2[p] == i:
                    anc[p, i] = True
            elif nsub == 3:
                s = (_P3[p] >> (2 * i)) & 3
                sub[p, i] = s
                if s and _A3[s - 1][p] == i:
                    anc[p, i] = True
    return sub, anc


_SUBTAB = {1: (np.zeros((64, 16), np.int64), np.eye(1, 16, 0, dtype=bool).repeat(64, 0)),
           2: _subset_tables(2), 3: _subset_tables(3)}


def _field(B, pos, n):
    if n == 0:
        return np.zeros(len(B), np.int64)
    return (B[:, pos:pos + n].astype(np.int64) << np.arange(n)).sum(1)


def _read_indices(B, pos, part, nsub, ibits):
    """Indexbits (Anker-Pixel haben ein Bit weniger) -> (N,16) Indizes, Endposition (konstant)."""
    sub, anc = _SUBTAB[nsub]
    a = anc[part]                                 # (N,16)
    nb = ibits - a.astype(np.int64)               # (N,16)
    offs = pos + np.concatenate([np.zeros((len(B), 1), np.int64), np.cumsum(nb, 1)[:, :-1]], 1)
    out = np.zeros((len(B), 16), np.int64)
    rows = np.arange(len(B))[:, None]
    for k in range(ibits):
        bit = B[rows, np.minimum(offs + k, 127)].astype(np.int64)
        out |= np.where(k < nb, bit << k, 0)
    return out, pos + 16 * ibits - nsub, sub[part]


# ---------------------------------------------------------------- BC7
_BC7 = [  # nsub, pbits(partition), rot, isel, cbits, abits, ep_pbits, shared_pbits, ib0, ib1
    (3, 4, 0, 0, 4, 0, 1, 0, 3, 0), (2, 6, 0, 0, 6, 0, 0, 1, 3, 0), (3, 6, 0, 0, 5, 0, 0, 0, 2, 0),
    (2, 6, 0, 0, 7, 0, 1, 0, 2, 0), (1, 0, 2, 1, 5, 6, 0, 0, 2, 3), (1, 0, 2, 0, 7, 8, 0, 0, 2, 2),
    (1, 0, 0, 0, 7, 7, 1, 0, 4, 0), (2, 6, 0, 0, 5, 5, 1, 0, 2, 0)]


def _expand_q(v, bits):
    v = (v << (8 - bits)) & 255
    return v | (v >> bits)


def _bc7_chunk(blk):
    N = len(blk)
    B = np.unpackbits(blk, axis=1, bitorder='little')
    out = np.zeros((N, 16, 4), np.uint8)
    first = np.argmax(B[:, :8], 1)
    valid = B[:, :8].any(1)
    for m in range(8):
        sel = np.nonzero(valid & (first == m))[0]
        if not len(sel):
            continue
        Bm = B[sel]
        ns, pb, rb, ib, cb, ab, epb, spb, i0, i1 = _BC7[m]
        n = len(sel)
        pos = m + 1
        part = _field(Bm, pos, pb); pos += pb
        rot = _field(Bm, pos, rb); pos += rb
        isel = _field(Bm, pos, ib); pos += ib
        mpb = epb or spb
        ep = np.zeros((n, 4, ns * 2), np.int64)        # R,G,B,A
        for c in range(3):
            for e in range(ns * 2):
                ep[:, c, e] = _field(Bm, pos, cb) << mpb; pos += cb
        if ab:
            for e in range(ns * 2):
                ep[:, 3, e] = _field(Bm, pos, ab) << mpb; pos += ab
        else:
            ep[:, 3, :] = 255
        if mpb:
            for s in range(ns):
                pa = _field(Bm, pos, mpb); pos += mpb
                pbv = pa if spb else _field(Bm, pos, mpb)
                if not spb:
                    pos += mpb
                for c in range(4):
                    ep[:, c, 2 * s] |= pa
                    ep[:, c, 2 * s + 1] |= pbv
        ep[:, :3] = _expand_q(ep[:, :3], cb + mpb)
        if ab:
            ep[:, 3] = _expand_q(ep[:, 3], ab + mpb)
        idx0, pos2, subs = _read_indices(Bm, pos, part, ns, i0)
        if i1:
            idx1, _, _ = _read_indices(Bm, pos2, np.zeros(n, np.int64), 1, i1)
        else:
            idx1 = idx0
        f0, f1 = _FACT[i0], _FACT[i1 if i1 else i0]
        ci = np.where(isel[:, None] == 1, idx1, idx0)
        ai = np.where(isel[:, None] == 1, idx0, idx1)
        fc = np.where(isel[:, None] == 1, f1[np.minimum(ci, len(f1) - 1)], f0[np.minimum(ci, len(f0) - 1)])
        fa = np.where(isel[:, None] == 1, f0[np.minimum(ai, len(f0) - 1)], f1[np.minimum(ai, len(f1) - 1)])
        e0 = np.take_along_axis(ep, (2 * subs)[:, None, :].repeat(4, 1), 2)      # (n,4,16)
        e1 = np.take_along_axis(ep, (2 * subs + 1)[:, None, :].repeat(4, 1), 2)
        rgb = (e0[:, :3] * (64 - fc[:, None]) + e1[:, :3] * fc[:, None] + 32) >> 6
        a = (e0[:, 3] * (64 - fa) + e1[:, 3] * fa + 32) >> 6
        px = np.concatenate([rgb, a[:, None]], 1).transpose(0, 2, 1)             # (n,16,4)
        for r, ch in ((1, 0), (2, 1), (3, 2)):
            k = rot == r
            if k.any():
                tmp = px[k, :, 3].copy()
                px[k, :, 3] = px[k, :, ch]
                px[k, :, ch] = tmp
        out[sel] = px.astype(np.uint8)
    return out


def decode_bc7(data, w, h, chunk=32768):
    blk = np.frombuffer(data, np.uint8, _bc_size(w, h, 16)).reshape(-1, 16)
    px = np.concatenate([_bc7_chunk(blk[i:i + chunk]) for i in range(0, len(blk), chunk)])
    return _blocks_to_image(px, w, h)


# ---------------------------------------------------------------- BC6H (unsigned)
# Modusinfo: transformed, partition, endpointbits, deltabits(r,g,b)
_BC6_INFO = {0: (1, 1, 10, (5, 5, 5)), 1: (1, 1, 7, (6, 6, 6)), 2: (1, 1, 11, (5, 4, 4)), 3: (0, 0, 10, (10, 10, 10)),
             6: (1, 1, 11, (4, 5, 4)), 7: (1, 0, 11, (9, 9, 9)), 10: (1, 1, 11, (4, 4, 5)), 11: (1, 0, 12, (8, 8, 8)),
             14: (1, 1, 9, (5, 5, 5)), 15: (1, 0, 16, (4, 4, 4)), 18: (1, 1, 8, (6, 5, 5)), 22: (1, 1, 8, (5, 6, 5)),
             26: (1, 1, 8, (5, 5, 6)), 30: (0, 1, 6, (6, 6, 6))}
# Bit-Layout je Modus: (Kanal 0=R 1=G 2=B, Endpunkt 0..3, Bits, Shift)
R, G, B_ = 0, 1, 2
_BC6_LAYOUT = {
    2: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 5, 0), (R, 0, 1, 10), (G, 2, 4, 0), (G, 1, 4, 0),
        (G, 0, 1, 10), (B_, 3, 1, 0), (G, 3, 4, 0), (B_, 1, 4, 0), (B_, 0, 1, 10), (B_, 3, 1, 1), (B_, 2, 4, 0),
        (R, 2, 5, 0), (B_, 3, 1, 2), (R, 3, 5, 0), (B_, 3, 1, 3)],
    3: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 10, 0), (G, 1, 10, 0), (B_, 1, 10, 0)],
    6: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 4, 0), (R, 0, 1, 10), (G, 3, 1, 4), (G, 2, 4, 0),
        (G, 1, 5, 0), (G, 0, 1, 10), (G, 3, 4, 0), (B_, 1, 4, 0), (B_, 0, 1, 10), (B_, 3, 1, 1), (B_, 2, 4, 0),
        (R, 2, 4, 0), (B_, 3, 1, 0), (B_, 3, 1, 2), (R, 3, 4, 0), (G, 2, 1, 4), (B_, 3, 1, 3)],
    7: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 9, 0), (R, 0, 1, 10), (G, 1, 9, 0), (G, 0, 1, 10),
        (B_, 1, 9, 0), (B_, 0, 1, 10)],
    10: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 4, 0), (R, 0, 1, 10), (B_, 2, 1, 4), (G, 2, 4, 0),
         (G, 1, 4, 0), (G, 0, 1, 10), (B_, 3, 1, 0), (G, 3, 4, 0), (B_, 1, 5, 0), (B_, 0, 1, 10), (B_, 2, 4, 0),
         (R, 2, 4, 0), (B_, 3, 1, 1), (B_, 3, 1, 2), (R, 3, 4, 0), (B_, 3, 1, 4), (B_, 3, 1, 3)],
    11: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 8, 0), (R, 0, 1, 11), (R, 0, 1, 10), (G, 1, 8, 0),
         (G, 0, 1, 11), (G, 0, 1, 10), (B_, 1, 8, 0), (B_, 0, 1, 11), (B_, 0, 1, 10)],
    14: [(R, 0, 9, 0), (B_, 2, 1, 4), (G, 0, 9, 0), (G, 2, 1, 4), (B_, 0, 9, 0), (B_, 3, 1, 4), (R, 1, 5, 0),
         (G, 3, 1, 4), (G, 2, 4, 0), (G, 1, 5, 0), (B_, 3, 1, 0), (G, 3, 4, 0), (B_, 1, 5, 0), (B_, 3, 1, 1),
         (B_, 2, 4, 0), (R, 2, 5, 0), (B_, 3, 1, 2), (R, 3, 5, 0), (B_, 3, 1, 3)],
    15: [(R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 4, 0)] + [(R, 0, 1, s) for s in range(15, 9, -1)] +
        [(G, 1, 4, 0)] + [(G, 0, 1, s) for s in range(15, 9, -1)] +
        [(B_, 1, 4, 0)] + [(B_, 0, 1, s) for s in range(15, 9, -1)],
    18: [(R, 0, 8, 0), (G, 3, 1, 4), (B_, 2, 1, 4), (G, 0, 8, 0), (B_, 3, 1, 2), (G, 2, 1, 4), (B_, 0, 8, 0),
         (B_, 3, 1, 3), (B_, 3, 1, 4), (R, 1, 6, 0), (G, 2, 4, 0), (G, 1, 5, 0), (B_, 3, 1, 0), (G, 3, 4, 0),
         (B_, 1, 5, 0), (B_, 3, 1, 1), (B_, 2, 4, 0), (R, 2, 6, 0), (R, 3, 6, 0)],
    22: [(R, 0, 8, 0), (B_, 3, 1, 0), (B_, 2, 1, 4), (G, 0, 8, 0), (G, 2, 1, 5), (G, 2, 1, 4), (B_, 0, 8, 0),
         (G, 3, 1, 5), (B_, 3, 1, 4), (R, 1, 5, 0), (G, 3, 1, 4), (G, 2, 4, 0), (G, 1, 6, 0), (G, 3, 4, 0),
         (B_, 1, 5, 0), (B_, 3, 1, 1), (B_, 2, 4, 0), (R, 2, 5, 0), (B_, 3, 1, 2), (R, 3, 5, 0), (B_, 3, 1, 3)],
    26: [(R, 0, 8, 0), (B_, 3, 1, 1), (B_, 2, 1, 4), (G, 0, 8, 0), (B_, 2, 1, 5), (G, 2, 1, 4), (B_, 0, 8, 0),
         (B_, 3, 1, 5), (B_, 3, 1, 4), (R, 1, 5, 0), (G, 3, 1, 4), (G, 2, 4, 0), (G, 1, 5, 0), (B_, 3, 1, 0),
         (G, 3, 4, 0), (B_, 1, 6, 0), (B_, 2, 4, 0), (R, 2, 5, 0), (B_, 3, 1, 2), (R, 3, 5, 0), (B_, 3, 1, 3)],
    30: [(R, 0, 6, 0), (G, 3, 1, 4), (B_, 3, 1, 0), (B_, 3, 1, 1), (B_, 2, 1, 4), (G, 0, 6, 0), (G, 2, 1, 5),
         (B_, 2, 1, 5), (B_, 3, 1, 2), (G, 2, 1, 4), (B_, 0, 6, 0), (G, 3, 1, 5), (B_, 3, 1, 3), (B_, 3, 1, 5),
         (B_, 3, 1, 4), (R, 1, 6, 0), (G, 2, 4, 0), (G, 1, 6, 0), (G, 3, 4, 0), (B_, 1, 6, 0), (B_, 2, 4, 0),
         (R, 2, 6, 0), (R, 3, 6, 0)],
    0: [(G, 2, 1, 4), (B_, 2, 1, 4), (B_, 3, 1, 4), (R, 0, 10, 0), (G, 0, 10, 0), (B_, 0, 10, 0), (R, 1, 5, 0),
        (G, 3, 1, 4), (G, 2, 4, 0), (G, 1, 5, 0), (B_, 3, 1, 0), (G, 3, 4, 0), (B_, 1, 5, 0), (B_, 3, 1, 1),
        (B_, 2, 4, 0), (R, 2, 5, 0), (B_, 3, 1, 2), (R, 3, 5, 0), (B_, 3, 1, 3)],
    1: [(G, 2, 1, 5), (G, 3, 1, 4), (G, 3, 1, 5), (R, 0, 7, 0), (B_, 3, 1, 0), (B_, 3, 1, 1), (B_, 2, 1, 4),
        (G, 0, 7, 0), (B_, 2, 1, 5), (B_, 3, 1, 2), (G, 2, 1, 4), (B_, 0, 7, 0), (B_, 3, 1, 3), (B_, 3, 1, 5),
        (B_, 3, 1, 4), (R, 1, 6, 0), (G, 2, 4, 0), (G, 1, 6, 0), (G, 3, 4, 0), (B_, 1, 6, 0), (B_, 2, 4, 0),
        (R, 2, 6, 0), (R, 3, 6, 0)],
}


def _sext(v, bits):
    m = 1 << (bits - 1)
    return ((v & ((1 << bits) - 1)) ^ m) - m


def _unq(v, bits):
    if bits >= 15:
        return v
    mx = (1 << bits) - 1
    r = ((v << 15) + 0x4000) >> (bits - 1)
    r = np.where(v == 0, 0, r)
    return np.where(v == mx, 0xFFFF, r)          # D3D-Spezifikation: Maximalwert -> 0xFFFF


def _bc6_chunk(blk):
    N = len(blk)
    Bt = np.unpackbits(blk, axis=1, bitorder='little')
    out = np.zeros((N, 16, 3), np.float32)
    m2 = _field(Bt, 0, 2)
    m5 = _field(Bt, 0, 5)
    mode = np.where(m2 & 2, m5, m2)
    for m, (tr, part, eb, db) in _BC6_INFO.items():
        sel = np.nonzero(mode == m)[0]
        if not len(sel):
            continue
        Bm = Bt[sel]
        n = len(sel)
        pos = 5 if (m & 2) else 2
        ep = np.zeros((n, 3, 4), np.int64)
        for ch, e, nb, sh in _BC6_LAYOUT[m]:
            ep[:, ch, e] |= _field(Bm, pos, nb) << sh
            pos += nb
        ns = 2 if part else 1
        for i in range(1, ns * 2):
            for ch in range(3):
                if tr:
                    d = _sext(ep[:, ch, i], db[ch])
                    ep[:, ch, i] = (d + ep[:, ch, 0]) & ((1 << eb) - 1)
        ep = _unq(ep, eb)
        if part:
            p = _field(Bm, pos, 5); pos += 5
        else:
            p = np.zeros(n, np.int64)
        ib = 3 if part else 4
        idx, _, subs = _read_indices(Bm, pos, p, ns, ib)
        f = _FACT[ib][idx]
        e0 = np.take_along_axis(ep, (2 * subs)[:, None, :].repeat(3, 1), 2)
        e1 = np.take_along_axis(ep, (2 * subs + 1)[:, None, :].repeat(3, 1), 2)
        v = (e0 * (64 - f[:, None]) + e1 * f[:, None] + 32) >> 6
        v = (v * 31) >> 6                             # finish_unquantize (unsigned)
        out[sel] = (v.astype(np.uint16).view(np.float16).astype(np.float32)).transpose(0, 2, 1)
    return out


def decode_bc6h(data, w, h, chunk=32768):
    """-> (h, w, 3) float32, linear HDR"""
    blk = np.frombuffer(data, np.uint8, _bc_size(w, h, 16)).reshape(-1, 16)
    px = np.concatenate([_bc6_chunk(blk[i:i + chunk]) for i in range(0, len(blk), chunk)])
    return _blocks_to_image(px, w, h, 3)


# ---------------------------------------------------------------- Unity-Formate
def decode_unity(fmt, data, w, h):
    """Unity TextureFormat -> (H,W,4) uint8 oder (H,W,3/4) float32. None = nicht unterstuetzt."""
    d = data
    if fmt == 10:
        return decode_bc1(d, w, h)
    if fmt == 12:
        return decode_bc3(d, w, h)
    if fmt == 26:
        return decode_bc4(d, w, h)
    if fmt == 27:
        return decode_bc5(d, w, h)
    if fmt == 25:
        return decode_bc7(d, w, h)
    if fmt == 24:
        return decode_bc6h(d, w, h)
    n = w * h
    if fmt == 4:      # RGBA32
        return np.frombuffer(d, np.uint8, n * 4).reshape(h, w, 4)
    if fmt == 3:      # RGB24
        a = np.frombuffer(d, np.uint8, n * 3).reshape(h, w, 3)
        return np.concatenate([a, np.full((h, w, 1), 255, np.uint8)], 2)
    if fmt == 5:      # ARGB32
        return np.frombuffer(d, np.uint8, n * 4).reshape(h, w, 4)[:, :, [1, 2, 3, 0]]
    if fmt == 14:     # BGRA32
        return np.frombuffer(d, np.uint8, n * 4).reshape(h, w, 4)[:, :, [2, 1, 0, 3]]
    if fmt == 1:      # Alpha8
        a = np.frombuffer(d, np.uint8, n).reshape(h, w, 1)
        return np.concatenate([np.full((h, w, 3), 255, np.uint8), a], 2)
    if fmt == 7:      # RGB565
        v = np.frombuffer(d, '<u2', n).reshape(h, w).astype(np.int32)
        rgb = _expand565(v).astype(np.uint8)
        return np.concatenate([rgb, np.full((h, w, 1), 255, np.uint8)], 2)
    if fmt in (2, 13):  # ARGB4444 / RGBA4444
        v = np.frombuffer(d, '<u2', n).reshape(h, w)
        c = [((v >> s) & 15).astype(np.uint8) * 17 for s in (12, 8, 4, 0)]
        order = [1, 2, 3, 0] if fmt == 2 else [0, 1, 2, 3]
        return np.stack([c[i] for i in order], -1)
    if fmt == 17:     # RGBAHalf
        return np.frombuffer(d, '<f2', n * 4).reshape(h, w, 4).astype(np.float32)
    if fmt == 20:     # RGBAFloat
        return np.frombuffer(d, '<f4', n * 4).reshape(h, w, 4).copy()
    return None
