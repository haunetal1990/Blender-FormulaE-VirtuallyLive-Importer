# -*- coding: utf-8 -*-
"""Unity-Texturen -> PNG/HDR-Dateien im Cache (ohne Pillow, ohne bpy)."""
import os
import struct
import zlib

import numpy as np

from . import unity as U
from . import texdecode as D
from . import crunch_py as C

_BPB = {10: 8, 26: 8, 12: 16, 27: 16, 25: 16, 24: 16}           # Bytes pro 4x4-Block
_BPP = {4: 4, 3: 3, 5: 4, 14: 4, 1: 1, 7: 2, 2: 2, 13: 2, 17: 8, 20: 16}


def _level_size(fmt, w, h):
    if fmt in _BPB:
        return D._bc_size(w, h, _BPB[fmt])
    return w * h * _BPP.get(fmt, 4)


def pick_level(w, h, mips, max_size):
    lv = 0
    if max_size:
        while lv + 1 < max(1, mips) and max(w >> lv, h >> lv) > max_size:
            lv += 1
    return lv


def decode_level(fmt, data, w, h, mips, max_size=0):
    """-> (pixels, w, h); pixels (h,w,4) uint8 oder float32 (HDR), Zeilen unten->oben (Unity)."""
    data = bytes(data)
    if fmt in (28, 29):                                           # Crunch
        lv = pick_level(w, h, mips, max_size)
        cf, lw, lh, blocks = C.unpack_level(data, lv)
        px = D.decode_bc1(blocks, lw, lh) if cf == 'DXT1' else D.decode_bc3(blocks, lw, lh)
        return px, lw, lh
    lv = pick_level(w, h, mips, max_size)
    ofs = 0
    for i in range(lv):
        ofs += _level_size(fmt, max(1, w >> i), max(1, h >> i))
    lw, lh = max(1, w >> lv), max(1, h >> lv)
    px = D.decode_unity(fmt, data[ofs:ofs + _level_size(fmt, lw, lh)], lw, lh)
    return px, lw, lh


def fix_normal(px):
    """Unity DXT5nm (x in A, y in G) -> RGB-Normalmap. px: (h,w,4) uint8."""
    sm = px[::8, ::8].astype(np.float32) / 255.0                 # Stichprobe fuer die Erkennung
    R, G, B, A = sm[..., 0], sm[..., 1], sm[..., 2], sm[..., 3]
    if A.std() < 0.01 and B.mean() > 0.6:
        return px[..., :3]
    rgb_equal = np.abs(R - G).mean() < 0.02 and np.abs(B - G).mean() < 0.02
    if not (rgb_equal or R.mean() > 0.9) or A.std() < 0.005:
        return px[..., :3]
    out = np.empty(px.shape[:2] + (3,), np.uint8)
    out[..., 0] = px[..., 3]
    out[..., 1] = px[..., 1]
    x = px[..., 3].astype(np.float32) * (2 / 255.0) - 1
    y = px[..., 1].astype(np.float32) * (2 / 255.0) - 1
    z = x * x
    z += y * y
    np.subtract(1, z, out=z)
    np.clip(z, 0, 1, out=z)
    np.sqrt(z, out=z)
    out[..., 2] = (z * 127.5 + 128.0).astype(np.uint8)
    return out


def write_png(path, px, flip=True, level=1):
    """px: (h,w,3|4) uint8. flip=True: Unity (unten zuerst) -> PNG (oben zuerst)."""
    h, w, c = px.shape
    if flip:
        px = px[::-1]
    raw = np.concatenate([np.zeros((h, 1), np.uint8), np.ascontiguousarray(px).reshape(h, w * c)], 1).tobytes()

    def chunk(tag, body):
        return struct.pack('>I', len(body)) + tag + body + struct.pack('>I', zlib.crc32(tag + body) & 0xFFFFFFFF)
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 6 if c == 4 else 2, 0, 0, 0)
    tmp = path + '.tmp'
    with open(tmp, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', zlib.compress(raw, level)) +
                chunk(b'IEND', b''))
    os.replace(tmp, path)


class TextureCache:
    """Dekodiert Texturen bei Bedarf und legt sie als PNG im Cache-Ordner ab (wiederverwendbar)."""

    def __init__(self, env, cache_dir, max_size=0, log=print):
        self.env = env
        self.dir = cache_dir
        self.max_size = max_size
        self.log = log
        self.done = {}
        self.failed = []
        os.makedirs(cache_dir, exist_ok=True)

    def _base(self, o, normal):
        t = U.read_texture2d(o, self.env, want_data=False)
        sub = os.path.join(self.dir, U.safe_name(o.sf.name))
        tag = '' if not self.max_size else '_max%d' % self.max_size
        return t, sub, os.path.join(sub, '%s_%d%s%s' % (U.safe_name(t['name']), o.path_id, tag, '_n' if normal else ''))

    def cached_path(self, o, normal=False):
        """Path of an already decoded PNG or None (does not decode)."""
        try:
            _, _, base = self._base(o, normal)
        except Exception:
            return None
        return base + '.png' if os.path.isfile(base + '.png') else None

    def accept(self, kind, o, normal, result, failures):
        """Take over a result from a worker process."""
        key = (o.sf.name, o.path_id, 'arr') if kind == 'arr' else (o.sf.name, o.path_id, normal)
        self.done[key] = result if kind != 'arr' else (result or [])
        self.failed.extend(failures or [])

    def texture(self, o, normal=False):
        """Texture2D -> (pfad, hat_alpha) oder None"""
        key = (o.sf.name, o.path_id, normal)
        if key in self.done:
            return self.done[key]
        self.done[key] = None
        try:
            t = U.read_texture2d(o, self.env, want_data=False)
        except Exception as ex:
            self.failed.append('%s:%d (%s)' % (o.sf.name, o.path_id, ex))
            return None
        if t['width'] <= 0 or t['height'] <= 0:
            return None
        sub = os.path.join(self.dir, U.safe_name(o.sf.name))
        tag = '' if not self.max_size else '_max%d' % self.max_size
        base = os.path.join(sub, '%s_%d%s%s' % (U.safe_name(t['name']), o.path_id, tag, '_n' if normal else ''))
        for ext, alpha in (('.png', True),):
            if os.path.isfile(base + ext):
                res = (base + ext, os.path.isfile(base + '.alpha'))
                self.done[key] = res
                return res
        try:
            t = U.read_texture2d(o, self.env, want_data=True)
            if not t['data']:
                self.failed.append('%s (data missing: %s)' % (t['name'], (t.get('stream') or ('',))[0]))
                return None
            px, w, h = decode_level(t['format'], t['data'], t['width'], t['height'], t['mips'], self.max_size)
        except Exception as ex:
            self.failed.append('%s (%s: %s)' % (t.get('name', '?'), U.TEXFMT.get(t.get('format'), t.get('format')), ex))
            return None
        if px is None:
            self.failed.append('%s (format %s not supported)' % (t['name'], U.TEXFMT.get(t['format'], t['format'])))
            return None
        if px.dtype != np.uint8:                                  # HDR -> 8 Bit fuer normale Materialtexturen
            px = (np.clip(px[..., :4], 0, 1) * 255 + 0.5).astype(np.uint8)
            if px.shape[2] == 3:
                px = np.concatenate([px, np.full(px.shape[:2] + (1,), 255, np.uint8)], 2)
        os.makedirs(sub, exist_ok=True)
        has_alpha = False
        if normal:
            out = fix_normal(px)
        else:
            has_alpha = bool((px[..., 3] < 250).any())
            out = px if has_alpha else px[..., :3]
        write_png(base + '.png', out)
        if has_alpha:
            open(base + '.alpha', 'w').close()
        res = (base + '.png', has_alpha)
        self.done[key] = res
        return res

    def array_layers(self, o):
        """Texture2DArray -> Liste von Pfaden (Ebene 0 Farbe, 1 Metallic/Glaette, 2 Normal)."""
        key = (o.sf.name, o.path_id, 'arr')
        if key in self.done:
            return self.done[key]
        self.done[key] = []
        try:
            r = o.reader()
            name = r.string()
            w, h, depth, fmt, mips, dsize = [r.i32() for _ in range(6)]
            r.i32(); r.i32(); r.f32(); r.i32()
            r.i32()
            r.bool(); r.align()
            n = r.i32()
            data = bytes(r.b[r.p:r.p + n])
            if n == 0:
                off, size, path = r.u32(), r.u32(), r.string()
                data = self.env.read_stream(o.sf, path, off, size) or b''
        except Exception as ex:
            self.failed.append('Texture2DArray %s:%d (%s)' % (o.sf.name, o.path_id, ex))
            return []
        if depth <= 0 or not data:
            return []
        per = len(data) // depth
        sub = os.path.join(self.dir, U.safe_name(o.sf.name))
        os.makedirs(sub, exist_ok=True)
        tag = '' if not self.max_size else '_max%d' % self.max_size
        out = []
        for i in range(depth):
            normal = (i == 2)
            p = os.path.join(sub, '%s_%d_layer%d%s%s.png' % (U.safe_name(name), o.path_id, i, tag, '_n' if normal else ''))
            if not os.path.isfile(p):
                try:
                    px, lw, lh = decode_level(fmt, data[i * per:(i + 1) * per], w, h, mips, self.max_size)
                except Exception as ex:
                    self.failed.append('%s layer %d (%s)' % (name, i, ex))
                    out.append(None)
                    continue
                write_png(p, fix_normal(px) if normal else px[..., :3])
            out.append(p)
        self.done[key] = out
        return out

    def skybox(self, cube_obj, rotation, scene_name, height=1024):
        """Cubemap -> Equirect-Panorama (.hdr). -> Pfad oder None"""
        try:
            t = U.read_texture2d(cube_obj, self.env, want_data=False)
            p = os.path.join(self.dir, 'sky_%s_%s_rot%d.hdr' % (U.safe_name(scene_name), U.safe_name(t['name']),
                                                                 int(round(rotation))))
            if os.path.isfile(p):
                return p
            t = U.read_texture2d(cube_obj, self.env, want_data=True)
            if not t['data']:
                self.failed.append('skybox %s (data missing)' % t['name'])
                return None
            w = t['width']
            stride = len(t['data']) // 6
            # Mip so waehlen, dass Faces <= height/... (1024er Faces reichen fuer 2048x1024-Panorama)
            lv = pick_level(w, w, t['mips'], 1024)
            faces = []
            for i in range(6):
                face = bytes(t['data'][i * stride:(i + 1) * stride])
                px, fw, fh = decode_level(t['format'], face, w, w, t['mips'], 1024)
                if px is None:
                    self.failed.append('skybox %s (format %s)' % (t['name'], U.TEXFMT.get(t['format'])))
                    return None
                if px.dtype == np.uint8:
                    px = U._srgb_to_linear(px[..., :3].astype(np.float32) / 255.0)
                faces.append(px[..., :3].astype(np.float32))
            pano = U.cubemap_to_equirect(faces, rotation, height=min(height, faces[0].shape[0]))
            U.write_hdr(p, pano)
            return p
        except Exception as ex:
            self.failed.append('skybox (%s)' % ex)
            return None
