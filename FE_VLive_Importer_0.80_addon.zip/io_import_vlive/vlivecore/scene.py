# -*- coding: utf-8 -*-
"""Szene eines Levels einsammeln (Hierarchie, Renderer, Materialien, Skybox) - ohne bpy."""
import re

import numpy as np

from . import unity as U

CID = U.CID


class SceneData:
    def __init__(self, name):
        self.name = name
        self.nodes = []
        self.materials = {}          # key -> Definition (Texturen als ObjInfo-Referenzen)
        self.skybox = None
        self.stats = dict(renderer=0, static_batched=0, mesh_missing=0, lod_skipped=0)


def _material_def(env, mo, shader_names):
    m = U.read_material(mo)
    sname = ''
    so = mo.sf.resolve(m['shader'])
    if so is not None:
        k = (so.sf.name, so.path_id)
        if k not in shader_names:
            try:
                shader_names[k] = U.read_shader_name(so)
            except Exception:
                shader_names[k] = ''
        sname = shader_names[k]
    texs = {}
    for slot, te in m['textures'].items():
        if not te['tex'][1]:
            continue
        to = mo.sf.resolve(te['tex'])
        if to is None:
            continue
        if to.cid == 187:
            for li in range(3):
                texs['%s#%d' % (slot, li)] = dict(obj=to, layer=li, scale=te['scale'], offset=te['offset'])
            continue
        if to.cid != CID['Texture2D']:
            continue
        is_normal = slot in ('_BumpMap', '_DetailNormalMap', '_NormalMap') or 'normal' in slot.lower()
        texs[slot] = dict(obj=to, normal=is_normal, scale=te['scale'], offset=te['offset'])
    return dict(name=m['name'], shader=sname, keywords=m['keywords'], queue=m['queue'], tags=m['tags'],
                slots=sorted(k for k, v in m['textures'].items() if v['tex'][1]),
                st={k: (v['scale'], v['offset']) for k, v in m['textures'].items()},
                textures=texs, colors=m['colors'], floats=m['floats'])


SPLAT_SET = re.compile(r'set\s*_?0*(\d+)', re.I)


def is_splat(d):
    sh = (d.get('shader') or '').lower()
    return 'distingo' in sh or 'terrain splat' in sh or '_Splat0' in d.get('slots', [])


def _tilingset_layers(env, nn, cache):
    """Materials 'Tilingset_NN_Layer0..3' (layer definitions applied at runtime by a script)."""
    if nn in cache:
        return cache[nn]
    want = {'tilingset_%02d_layer%d' % (nn, i): i for i in range(4)}
    found = {}
    for sf in list(env.files.values()):
        for mo in sf.by_class(CID['Material']):
            try:
                nm = U.read_name(mo).lower()
            except Exception:
                continue
            if nm in want and want[nm] not in found:
                found[want[nm]] = mo
    cache[nn] = found
    return found


def distingo_tiling(d):
    """Distingo Mesh Terrain Splat (from the DXBC): layer UV = (uv0 * _SplatN_ST) * _SplatNUV * offset[N]
    up close, * UVMin[N] far away (blend by depth * UVCutoff); triplanar: world pos * triPlanerMultiplier
    * offset[N].  -> dict or None when the material does not carry these values."""
    c, fl = d.get('colors', {}), d.get('floats', {})
    near = c.get('offset')
    if near is None or not any(abs(x) > 1e-6 for x in near[:4]):
        return None
    far = c.get('UVMin') or near
    suv = [list(c.get('_Splat%dUV' % i, [1, 1, 0, 0])[:2]) for i in range(4)]
    suv = [s if any(abs(x) > 1e-6 for x in s) else [1, 1] for s in suv]
    def vec(name, dflt):
        v = c.get(name)
        return list(v[:4]) if v is not None else [dflt] * 4
    return dict(near=list(near[:4]), far=list(far[:4]), suv=suv,
                normal=vec('normalMod', 1.0), brightness=vec('_Brightness', 1.0),
                smooth=[float(fl.get('_Smoothness%d' % i, 0.0)) for i in range(4)],
                metal=[float(fl.get('_Metallic%d' % i, 0.0)) for i in range(4)],
                triplanar=float(fl.get('UseTriPlanar', 0) or 0) >= 0.5,
                tri_mult=float(fl.get('triPlanerMultiplier', 1) or 1))


SPLAT_TILE_M = 15.0      # metres per terrain texture tile (Distingo sets the real value at runtime)


def _derive_splat(env, sd, key, node, mo_mesh, shader_names, ts_cache, log):
    """Distingo splat material: fill empty layers from Tilingset_NN_Layer0-3 and give layers with
    tiling 1 a tiling derived from the mesh size. -> material key (possibly a per-mesh copy)"""
    d = sd.materials[key]
    nd = None
    suffix = ''
    if not any(k.startswith('_Splat') for k in d['textures']):
        m = SPLAT_SET.search(node.get('mesh_name') or '') or SPLAT_SET.search(node.get('name') or '')
        if m:
            nn = int(m.group(1))
            layers = _tilingset_layers(env, nn, ts_cache)
            if layers:
                nd = dict(d)
                nd['textures'] = dict(d['textures'])
                for i, lmo in layers.items():
                    ld = _material_def(env, lmo, shader_names)
                    for src, dst in (('_MainTex', '_Splat%d' % i), ('_BumpMap', '_Normal%d' % i)):
                        if src in ld['textures']:
                            t = dict(ld['textures'][src])
                            sc, off = d.get('st', {}).get('_Splat%d' % i, ([1, 1], [0, 0]))
                            t['scale'], t['offset'] = list(sc), list(off)   # the splat shader uses _SplatN_ST
                            nd['textures'][dst] = t
                nd['name'] = '%s_Set%02d' % (d.get('name', 'Splat'), nn)
                suffix += '#set%02d' % nn
            else:
                log('  ! splat layers Tilingset_%02d_Layer0-3 not found' % nn)
    base = nd or d
    dg = node.get('distingo')
    if dg and distingo_tiling(base) is None:       # values of this object's Distingo component
        nd = dict(base)
        nd['colors'] = dict(base.get('colors', {}))
        nd['floats'] = dict(base.get('floats', {}))
        c, f = nd['colors'], nd['floats']
        c['offset'] = list(dg['near'])
        c['UVMin'] = list(dg['far'])
        c['normalMod'] = list(dg['normal'])
        c['_Brightness'] = list(dg['brightness'])
        for i, (u, v) in enumerate(dg['uv'][:4]):
            c['_Splat%dUV' % i] = [u, v, 0.0, 0.0]
        for i in range(4):
            f['_Smoothness%d' % i] = dg['smooth'][i]
            f['_Metallic%d' % i] = dg['metal'][i]
        f['UseTriPlanar'] = 1.0 if dg['triplanar'] else 0.0
        f['triPlanerMultiplier'] = dg['tri_mult']
        suffix += '#dg' + '_'.join('%g' % x for x, _ in dg['uv'][:4])
        base = nd
    dt = distingo_tiling(base)
    if dt is not None:                             # real Distingo values present -> use them
        base['distingo'] = dt                      # (base is the shared def or our own copy)
        needs_tiling = False
    else:
        needs_tiling = any(k.startswith('_Splat') and v.get('scale', [1, 1]) == [1, 1]
                           for k, v in base['textures'].items())
    if needs_tiling and '_SplatTiling' not in base.get('floats', {}):
        try:
            mm = U.read_mesh(mo_mesh)
            pos = mm['attrs']['position']
            uv = mm['attrs'].get('uv0')
            sc = np.linalg.norm(node['world'][:3, :3], axis=0).max()
            ext = float(np.ptp(pos[:, [0, 2]], axis=0).max() * sc)
            uv_span = float(np.ptp(uv, axis=0).max()) if uv is not None and len(uv) else 1.0
            tiling = max(1.0, round(ext / max(SPLAT_TILE_M, 0.1) / max(uv_span, 1e-3), 1))
        except Exception:
            tiling = 40.0
        nd = dict(base)
        nd['floats'] = dict(base.get('floats', {}))
        nd['floats']['_SplatTiling'] = tiling
        suffix += '#t%g' % tiling
    if nd is None:
        return key
    nkey = key + suffix
    if nkey not in sd.materials:
        sd.materials[nkey] = nd
        nl = sum(1 for k in nd['textures'] if k.startswith('_Splat'))
        if nd.get('distingo'):
            dd = nd['distingo']
            log('  terrain material %s: %d layers, Distingo tiling %s%s' %
                (nd.get('name'), nl, ' / '.join('%g' % (s[0] * k) for s, k in zip(dd['suv'], dd['near'])),
                 ' (triplanar)' if dd['triplanar'] else ''))
        else:
            log('  terrain material %s: %d layers, tiling %g (estimated, ~%g m per tile)' %
                (nd.get('name'), nl, nd['floats'].get('_SplatTiling', 1), SPLAT_TILE_M))
    return nkey


def collect(env, sf, scene_name, log=print):
    sd = SceneData(scene_name)
    shader_names = {}
    ts_cache = {}
    tr_cache = {}

    def get_tr(o):
        k = (o.sf.name, o.path_id)
        if k not in tr_cache:
            tr_cache[k] = U.read_transform(o)
        return tr_cache[k]

    def material_key(mo):
        if mo is None or mo.cid != CID['Material']:
            return None
        key = '%s:%d' % (mo.sf.name, mo.path_id)
        if key not in sd.materials:
            try:
                sd.materials[key] = _material_def(env, mo, shader_names)
            except Exception as ex:
                log('  ! material %s unreadable: %s' % (key, ex))
                sd.materials[key] = dict(name='material_%d' % mo.path_id, textures={}, colors={}, floats={})
        return key

    # LOD-Zuordnung
    lod_of = {}
    for lo in sf.by_class(CID['LODGroup']):
        try:
            lg = U.read_lodgroup(lo)
        except Exception:
            continue
        for li, lod in enumerate(lg['lods']):
            for rp in lod['renderers']:
                ro = sf.resolve(rp)
                if ro is not None:
                    lod_of.setdefault((ro.sf.name, ro.path_id), li)

    roots = []
    for to in sf.by_class(CID['Transform']) + sf.by_class(CID['RectTransform']):
        try:
            if get_tr(to)['father'][1] == 0:
                roots.append(to)
        except Exception:
            continue

    nodes = sd.nodes

    def walk(to, parent_world, parent_idx, root_name, active_chain):
        stack = [(to, parent_world, parent_idx, active_chain)]
        while stack:
            to, parent_world, parent_idx, active_chain = stack.pop()
            t = get_tr(to)
            world = parent_world @ U.trs_matrix(t['pos'], t['rot'], t['scale'])
            go_o = sf.resolve(t['go'])
            go = None
            if go_o is not None:
                try:
                    go = U.read_gameobject(go_o)
                except Exception:
                    go = None
            name = go['name'] if go else 'Transform_%d' % to.path_id
            active = active_chain and (go['active'] if go else True)
            path = (nodes[parent_idx]['path'] + '/' + name) if parent_idx >= 0 else name
            node = dict(name=name, path=path, parent=parent_idx, root=root_name, active=active, world=world)
            idx = len(nodes)
            nodes.append(node)
            if go:
                mf = rend = None
                for cp in go['components']:
                    co = go_o.sf.resolve(cp)
                    if co is None:
                        continue
                    try:
                        if co.cid == CID['MeshFilter']:
                            mf = U.read_meshfilter(co)
                        elif co.cid == CID['MeshRenderer']:
                            rend = U.read_meshrenderer(co)
                            rend['_key'] = (co.sf.name, co.path_id)
                        elif co.cid == 114 and 'distingo' not in node and 200 < co.size < 8192:
                            if U.is_distingo_script(co):
                                dg = U.read_distingo(co)
                                if dg:
                                    node['distingo'] = dg
                        elif co.cid == CID['SkinnedMeshRenderer']:
                            rend = U.read_skinnedrenderer(co)
                            rend['_key'] = (co.sf.name, co.path_id)
                            mf = dict(mesh=rend['mesh'])
                            node['skinned'] = True
                    except Exception as ex:
                        log('  ! component on %s unreadable: %s' % (name, ex))
                if mf and rend:
                    mo = go_o.sf.resolve(mf['mesh']) if mf['mesh'][1] else None
                    if mo is None:
                        if mf['mesh'][1]:
                            sd.stats['mesh_missing'] += 1
                    else:
                        node['mesh'] = mo
                        node['mesh_name'] = U.read_name(mo)
                        node['renderer_enabled'] = rend['enabled']
                        node['cast_shadows'] = rend['cast_shadows']
                        mk = [material_key(go_o.sf.resolve(mp)) for mp in rend['materials']]
                        mk = [_derive_splat(env, sd, k, node, mo, shader_names, ts_cache, log)
                              if k and is_splat(sd.materials[k]) else k for k in mk]
                        node['materials'] = mk
                        if rend['sb_count']:
                            node['static_batch'] = [rend['sb_first'], rend['sb_count']]
                            sd.stats['static_batched'] += 1
                        lod = lod_of.get(rend['_key'])
                        if lod is not None:
                            node['lod'] = lod
                        sd.stats['renderer'] += 1
            for cp in reversed(t['children']):
                co = sf.resolve(cp)
                if co is not None:
                    stack.append((co, world, idx, active))

    for ro in roots:
        try:
            rn = U.read_gameobject(sf.resolve(get_tr(ro)['go']))['name']
        except Exception:
            rn = 'root_%d' % ro.path_id
        walk(ro, np.eye(4), -1, rn, True)

    # Skybox
    try:
        pp = U.read_skybox_material_pptr(sf)
        mo = sf.resolve(pp) if pp else None
        if mo is not None and mo.cid == CID['Material']:
            m = U.read_material(mo)
            te = m['textures'].get('_Tex')
            co = mo.sf.resolve(te['tex']) if te else None
            if co is not None and co.cid == 89:
                tint = m['colors'].get('_Tint', [0.5, 0.5, 0.5, 0.5])
                sd.skybox = dict(material=m['name'], cube=co, rotation=m['floats'].get('_Rotation', 0.0),
                                 exposure=m['floats'].get('_Exposure', 1.0),
                                 tint=[float(U._srgb_to_linear(np.float32(c)) * 4.59) for c in tint[:3]])
    except Exception as ex:
        log('  ! skybox unreadable: %s' % ex)
    return sd


def mesh_arrays(mo):
    """Mesh-ObjInfo -> dict wie frueher die .npz (position, normal, uv0.., sub0.., meta)."""
    m = U.read_mesh(mo)
    if 'position' not in m['attrs']:
        return None
    d = dict(m['attrs'])
    for i in range(len(m['submeshes'])):
        d['sub%d' % i] = U.submesh_indices(m, i).astype(np.uint32)
    d['meta'] = dict(name=m['name'], submeshes=len(m['submeshes']), vertex_count=m['vertex_count'])
    return d


# ---------------------------------------------------------------- Fahrlinien
def _world_points(sf, trs, root_pid):
    """World positions of the DIRECT children of a transform (in child order).
    Waypoints can carry their own sub-objects (markers far below the track) - those are ignored."""
    t = trs[root_pid]
    m = U.trs_matrix(t['pos'], t['rot'], t['scale'])
    out = []
    for c in t['children']:
        co = sf.resolve(c)
        if co is not None and co.path_id in trs:
            ct = trs[co.path_id]
            out.append((m @ U.trs_matrix(ct['pos'], ct['rot'], ct['scale']))[:3, 3].copy())
    return np.array(out) if out else np.zeros((0, 3))


def find_paths(env, sd, log=print, min_score=0.6):
    """Fahrlinien (Waypoints_*) und Boxengassen (PitLanePaths_*) aus sharedassets11 suchen,
    die zur Szene passen. -> Liste dict(name, points (N,3) Unity-Welt, cyclic)"""
    sa = env.get('sharedassets11.assets')
    if sa is None:
        log('  racing line: sharedassets11.assets missing')
        return []
    trs = {}
    for o in sa.by_class(CID['Transform']):
        try:
            trs[o.path_id] = U.read_transform(o)
        except Exception:
            pass
    # Belegungsraster der Szene (Objektpositionen, 25-m-Zellen)
    cell = 25.0
    occ = set()
    for nd in sd.nodes:
        w = nd['world']
        occ.add((int(np.floor(w[0, 3] / cell)), int(np.floor(w[2, 3] / cell))))
    if not occ:
        return []

    def score(pts):
        if not len(pts):
            return 0.0
        hit = 0
        for x, _, z in pts:
            cx, cz = int(np.floor(x / cell)), int(np.floor(z / cell))
            if any((cx + dx, cz + dz) in occ for dx in (-1, 0, 1) for dz in (-1, 0, 1)):
                hit += 1
        return hit / len(pts)

    found = []
    for pid, t in trs.items():
        if t['father'][1] != 0:
            continue
        try:
            name = U.read_gameobject(sa.resolve(t['go']))['name']
        except Exception:
            continue
        boxes = []
        if name.startswith('Waypoints_'):
            pts = _world_points(sa, trs, pid)
            kind = 'racing_line'
        elif name.startswith('PitLanePaths_'):
            # Linie = direkte Kinder von "GenericPath", deren Unterobjekte (point_NN) = Boxenplaetze
            pts = None
            boxes = []
            root_m = U.trs_matrix(t['pos'], t['rot'], t['scale'])
            for c in t['children']:
                co = sa.resolve(c)
                if co is None or co.path_id not in trs:
                    continue
                gp = trs[co.path_id]
                if U.read_gameobject(sa.resolve(gp['go']))['name'] != 'GenericPath':
                    continue
                gm = root_m @ U.trs_matrix(gp['pos'], gp['rot'], gp['scale'])
                pl = []
                for pc in gp['children']:
                    po = sa.resolve(pc)
                    if po is None or po.path_id not in trs:
                        continue
                    pt = trs[po.path_id]
                    pm = gm @ U.trs_matrix(pt['pos'], pt['rot'], pt['scale'])
                    pl.append(pm[:3, 3].copy())
                    for bc in pt['children']:
                        bo = sa.resolve(bc)
                        if bo is None or bo.path_id not in trs:
                            continue
                        bt = trs[bo.path_id]
                        bm = pm @ U.trs_matrix(bt['pos'], bt['rot'], bt['scale'])
                        bname = U.read_gameobject(sa.resolve(bt['go']))['name']
                        boxes.append((bname, bm[:3, 3].copy()))
                pts = np.array(pl) if pl else None
            if pts is None:
                continue
            kind = 'pit_lane'
        else:
            continue
        s = score(pts)
        if s >= min_score and len(pts) >= 2:
            d = np.linalg.norm(np.diff(pts, axis=0), axis=1)
            cyclic = kind == 'racing_line' and np.linalg.norm(pts[0] - pts[-1]) < 3 * max(d.mean(), 1e-3)
            found.append(dict(name=name, kind=kind, points=pts, cyclic=bool(cyclic), score=s,
                              boxes=boxes if kind == 'pit_lane' else [],
                              length=float(d.sum() + (np.linalg.norm(pts[0] - pts[-1]) if cyclic else 0))))
    # Fahrlinie(n): beste Treffer (Berlin hat z. B. zwei gleichwertige Varianten -> beide behalten)
    lines = [f for f in found if f['kind'] == 'racing_line']
    if not lines:
        return []
    top = max(f['score'] for f in lines)
    lines = [f for f in lines if f['score'] >= top - 0.05]
    keys = set(re.sub(r'_Option\w+$', '', f['name'][len('Waypoints_'):]) for f in lines)
    pits = [f for f in found if f['kind'] == 'pit_lane' and f['name'][len('PitLanePaths_'):] in keys]
    found = lines + pits
    for f in found:
        log('  %s: %s (%d points, %.0f m, match %.0f%%)' % (f['kind'], f['name'], len(f['points']),
                                                             f['length'], 100 * f['score']))
    return found
