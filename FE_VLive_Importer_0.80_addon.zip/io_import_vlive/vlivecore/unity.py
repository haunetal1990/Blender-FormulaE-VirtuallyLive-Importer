# -*- coding: utf-8 -*-
"""Unity 5.6 SerializedFile-Parser fuer "Formula E powered by Virtually Live" (ohne Fremdpakete ausser numpy)."""
import mmap
import os
import re
import struct

import numpy as np

# --------------------------------------------------------------------------
# Unity Klassen-IDs
# --------------------------------------------------------------------------
CID = dict(GameObject=1, Transform=4, Material=21, MeshRenderer=23, Texture2D=28,
           MeshFilter=33, Mesh=43, Shader=48, SkinnedMeshRenderer=137,
           LODGroup=205, RectTransform=224, Cubemap=89, LightmapSettings=157)
CNAME = {v: k for k, v in CID.items()}
CNAME.update({114: 'MonoBehaviour', 115: 'MonoScript', 65: 'BoxCollider', 64: 'MeshCollider',
              54: 'Rigidbody', 108: 'Light', 20: 'Camera', 82: 'AudioSource', 83: 'AudioClip',
              95: 'Animator', 111: 'Animation', 74: 'AnimationClip', 91: 'AnimatorController',
              212: 'SpriteRenderer', 213: 'Sprite', 222: 'CanvasRenderer', 223: 'Canvas',
              225: 'CanvasGroup', 135: 'SphereCollider', 136: 'CapsuleCollider',
              156: 'TerrainData', 218: 'Terrain', 198: 'ParticleSystem', 199: 'ParticleSystemRenderer',
              128: 'Font', 150: 'PreloadData', 215: 'ReflectionProbe', 220: 'LightProbeGroup',
              193: 'TrailRenderer?', 196: 'NavMeshSettings', 258: 'LightProbes', 120: 'LineRenderer'})


# --------------------------------------------------------------------------
# Binaer-Leser
# --------------------------------------------------------------------------
class Reader:
    __slots__ = ('b', 'p', 'e')

    def __init__(self, buf, pos=0, little=True):
        self.b = buf
        self.p = pos
        self.e = '<' if little else '>'

    def _u(self, fmt, n):
        v = struct.unpack_from(self.e + fmt, self.b, self.p)[0]
        self.p += n
        return v

    def u8(self):
        v = self.b[self.p]
        self.p += 1
        return v

    def bool(self): return self.u8() != 0
    def i16(self): return self._u('h', 2)
    def u16(self): return self._u('H', 2)
    def i32(self): return self._u('i', 4)
    def u32(self): return self._u('I', 4)
    def i64(self): return self._u('q', 8)
    def f32(self): return self._u('f', 4)

    def floats(self, n):
        v = struct.unpack_from(self.e + '%df' % n, self.b, self.p)
        self.p += 4 * n
        return list(v)

    def align(self, n=4):
        self.p = (self.p + n - 1) & ~(n - 1)

    def cstr(self):
        e = self.b.find(b'\0', self.p)
        v = bytes(self.b[self.p:e]).decode('utf-8', 'replace')
        self.p = e + 1
        return v

    def string(self):
        n = self.i32()
        if n < 0 or n > 10_000_000:
            raise ValueError('ungueltige Stringlaenge %d @%d' % (n, self.p - 4))
        v = bytes(self.b[self.p:self.p + n]).decode('utf-8', 'replace')
        self.p += n
        self.align()
        return v

    def bytes_arr(self):
        n = self.i32()
        if n < 0 or self.p + n > len(self.b):
            raise ValueError('ungueltige Byte-Array-Laenge %d' % n)
        v = self.b[self.p:self.p + n]
        self.p += n
        self.align()
        return v

    def count(self, limit=50_000_000):
        n = self.i32()
        if n < 0 or n > limit:
            raise ValueError('ungueltige Array-Laenge %d @%d' % (n, self.p - 4))
        return n

    def pptr(self):
        return (self.i32(), self.i64())

    def pptrs(self):
        return [self.pptr() for _ in range(self.count(1_000_000))]


# --------------------------------------------------------------------------
# SerializedFile (Format 17)
# --------------------------------------------------------------------------
class ObjInfo:
    __slots__ = ('path_id', 'start', 'size', 'cid', 'sf')

    def __init__(self, path_id, start, size, cid, sf):
        self.path_id, self.start, self.size, self.cid, self.sf = path_id, start, size, cid, sf

    def reader(self):
        return Reader(self.sf.buf, self.start, self.sf.little)


class SerializedFile:
    def __init__(self, path, env=None):
        self.path = path
        self.name = os.path.basename(path)
        self.env = env
        self._fh = open(path, 'rb')
        self.buf = mmap.mmap(self._fh.fileno(), 0, access=mmap.ACCESS_READ)
        h = Reader(self.buf, 0, False)
        self.meta_size, self.file_size, self.version, self.data_off = h.u32(), h.u32(), h.u32(), h.u32()
        if self.version != 17:
            raise ValueError('%s: Format %d nicht unterstuetzt (erwartet 17)' % (self.name, self.version))
        self.little = self.buf[16] == 0
        r = Reader(self.buf, 20, self.little)
        self.unity_version = r.cstr()
        self.platform = r.i32()
        self.type_tree = r.bool()
        if self.type_tree:
            print('WARNUNG: %s hat Type-Trees - wird ignoriert' % self.name)
        types = []
        for _ in range(r.i32()):
            cid = r.i32()
            r.u8()          # stripped
            r.i16()         # script index
            if cid == 114:
                r.p += 16
            r.p += 16
            if self.type_tree:
                nn, sb = r.i32(), r.i32()
                r.p += nn * 24 + sb
            types.append(cid)
        self.objects = {}
        for _ in range(r.i32()):
            r.align()
            pid = r.i64()
            start = r.u32()
            size = r.u32()
            ti = r.i32()
            self.objects[pid] = ObjInfo(pid, self.data_off + start, size, types[ti], self)
        for _ in range(r.i32()):      # script types
            r.i32()
            r.align()
            r.i64()
        self.externals = []
        for _ in range(r.i32()):
            r.cstr()
            r.p += 16
            r.i32()
            self.externals.append(r.cstr())

    def by_class(self, cid):
        return [o for o in self.objects.values() if o.cid == cid]

    def resolve(self, pptr):
        """PPtr (fileID, pathID) -> ObjInfo oder None."""
        fid, pid = pptr
        if pid == 0:
            return None
        if fid == 0:
            return self.objects.get(pid)
        if fid - 1 >= len(self.externals) or self.env is None:
            return None
        sf = self.env.get(self.externals[fid - 1])
        if sf is None:
            return None
        return sf.objects.get(pid)

    def close(self):
        try:
            self.buf.close()
            self._fh.close()
        except Exception:
            pass


class Environment:
    """Verwaltet alle Dateien in VLive_Data; laedt bei Bedarf."""

    def __init__(self, data_dir):
        self.dir = data_dir
        self.files = {}
        self.missing = set()

    def get(self, name):
        key = os.path.basename(name).lower()
        if key in self.files:
            return self.files[key]
        if key in self.missing:
            return None
        if key in ('unity default resources', 'unity_builtin_extra'):
            cand = [os.path.join(self.dir, 'Resources', key)]
        else:
            cand = [os.path.join(self.dir, os.path.basename(name))]
        for c in cand:
            if os.path.isfile(c):
                try:
                    sf = SerializedFile(c, self)
                except Exception as ex:
                    print('  ! kann %s nicht laden: %s' % (c, ex))
                    break
                self.files[key] = sf
                return sf
        self.missing.add(key)
        return None

    def read_stream(self, sf, path, offset, size):
        p = os.path.join(os.path.dirname(sf.path), os.path.basename(path))
        if not os.path.isfile(p):
            p = os.path.join(self.dir, os.path.basename(path))
        if not os.path.isfile(p):
            return None
        with open(p, 'rb') as f:
            f.seek(offset)
            return f.read(size)

    def close_all(self):
        for sf in self.files.values():
            sf.close()
        self.files.clear()


# --------------------------------------------------------------------------
# Klassen-Reader (Unity 5.6)
# --------------------------------------------------------------------------
def read_shader_name(o):
    """Shader 5.6: the name sits behind the SubShaders of m_ParsedForm, followed by
    customEditor, fallback, deps[], bool, platforms[n], offsets[n] ...  Vectorised search (numpy) -
    the Standard shader object is >20 MB."""
    le = '<' if o.sf.little else '>'
    n4 = o.size // 4
    if n4 < 8:
        return ''
    v = np.frombuffer(o.sf.buf, dtype=le + 'i4', count=n4, offset=o.start).astype(np.int64)
    idx = np.arange(n4)

    def words(n):                       # length in 4-byte words of an aligned string with n chars
        return (n + 3) // 4

    def at(i):
        return v[np.clip(i, 0, n4 - 1)]

    p = idx[(v >= 1) & (v <= 300)]
    q = p + 1 + words(at(p))                         # customEditor
    ok = (q < n4) & (at(q) >= 0) & (at(q) <= 300)
    p, q = p[ok], q[ok]
    r = q + 1 + words(at(q))                         # fallback
    ok = (r < n4) & (at(r) >= 0) & (at(r) <= 300)
    p, r = p[ok], r[ok]
    d = r + 1 + words(at(r))                         # dependencies count
    ok = (d < n4) & (at(d) >= 0) & (at(d) < 200)
    p, d = p[ok], d[ok]
    pl = d + 1 + 3 * at(d) + 1                       # PPtr = 3 words, then bool+align
    npl = at(pl)
    ok = (pl < n4) & (npl >= 1) & (npl <= 20)
    p, pl, npl = p[ok], pl[ok], npl[ok]
    ok = at(pl + 1 + npl) == npl                     # offsets[] has the same count
    p, pl, npl = p[ok], pl[ok], npl[ok]
    best = ''
    raw = o.sf.buf
    def printable(word_idx):
        n = int(v[word_idx])
        st = o.start + 4 * int(word_idx) + 4
        b = bytes(raw[st:st + n])
        return b if all(32 <= c <= 126 for c in b) else None

    for pi, pli, ni in zip(p[::-1], pl[::-1], npl[::-1]):   # last match wins
        plats = v[pli + 1:pli + 1 + ni]
        if ((plats < 0) | (plats >= 40)).any():
            continue
        name = printable(pi)
        if name is None:
            continue
        qi = pi + 1 + words(int(v[pi]))
        if printable(qi) is None or printable(qi + 1 + words(int(v[qi]))) is None:
            continue
        best = name.decode('ascii')
        break
    if not best:
        try:
            best = o.reader().string()
        except Exception:
            best = ''
    return best


def read_distingo(o):
    """RandomchaosLtd.Distingo.DistingoTerrainScript (MonoBehaviour), fields in declaration order
    (Assembly-CSharp.dll).  The script copies them to the shader at runtime:
    tmp_UVs -> _SplatNUV, BlendChannelNMax -> offset (near), BlendChannelNMin -> UVMin (far),
    BlendNChannelN -> normalMod, BrightnessN -> _Brightness, ChannelNSmoothness/Metalic,
    useTriPlanar / TriPlanerUVMultiplier.  -> dict or None"""
    r = o.reader()
    try:
        r.pptr(); r.bool(); r.align(); r.pptr(); r.string()          # MonoBehaviour header
        for _ in range(r.i32()):                                       # ShaderList
            r.string()
        r.string(); r.string()                                         # SelectedShader, lastSelectedShader
        tri_mult = r.floats(1)[0]
        is_mesh = r.bool(); r.align()
        r.floats(2)                                                    # SplattingDistance, DistanceOffSet
        near = r.floats(4); far = r.floats(4); nmod = r.floats(4)
        smooth = r.floats(4); metal = r.floats(4)
        r.floats(1)                                                    # BrightnessMod
        r.bool(); r.align()                                            # UseNormalShader
        r.floats(1)                                                    # MinMaxUVCutoff
        r.bool(); r.align()                                            # ShowFallOff
        for _ in range(r.i32()):                                       # OcclusionMaps
            r.pptr()
        for _ in range(r.i32()):                                       # ChannelMaterials
            r.pptr()
        r.floats(4)                                                    # OcclusionPower0-3
        bright = r.floats(4)
        r.pptr(); r.pptr()                                             # GlobalBlend/OcclusionTexture
        r.bool(); r.align()                                            # HasGlobalBlend
        r.floats(2)                                                    # BlendPower, OcclusionPower
        r.bool(); r.align()                                            # UpdateShadersInEditor
        r.pptr()                                                       # tm_SplatMap
        for _ in range(r.i32()):
            r.pptr()                                                   # tm_Splat
        for _ in range(r.i32()):
            r.pptr()                                                   # tm_Normal
        n = r.i32()
        if not 0 < n <= 8:
            return None
        uvs = [r.floats(2) for _ in range(n)]
        r.bool(); r.align()                                            # UseSpeculerPBR
        tri = r.bool()
    except Exception:
        return None
    if not is_mesh and not uvs:
        return None
    return dict(uv=uvs, near=near, far=far, normal=nmod, brightness=bright, smooth=smooth, metal=metal,
                triplanar=bool(tri), tri_mult=tri_mult)


def is_distingo_script(o):
    """MonoBehaviour whose MonoScript is DistingoTerrainScript (needs globalgamemanagers.assets),
    or - if that file is missing - one whose data parses as one."""
    try:
        r = o.reader()
        r.pptr(); r.bool(); r.align()
        so = o.sf.resolve(r.pptr())
        if so is not None:
            return so.reader().string() == 'DistingoTerrainScript'
    except Exception:
        pass
    return read_distingo(o) is not None


def read_name(o):
    try:
        return o.reader().string()
    except Exception:
        return ''


def read_gameobject(o):
    r = o.reader()
    comps = [r.pptr() for _ in range(r.count(10000))]
    layer = r.u32()
    name = r.string()
    tag = r.u16()
    active = r.bool()
    return dict(components=comps, layer=layer, name=name, tag=tag, active=active)


def read_transform(o):
    r = o.reader()
    go = r.pptr()
    rot = r.floats(4)          # x y z w
    pos = r.floats(3)
    scl = r.floats(3)
    children = r.pptrs()
    father = r.pptr()
    return dict(go=go, rot=rot, pos=pos, scale=scl, children=children, father=father)


def read_meshfilter(o):
    r = o.reader()
    return dict(go=r.pptr(), mesh=r.pptr())


def _read_renderer_base(r):
    go = r.pptr()
    enabled = r.bool()
    cast = r.u8()                # 0 aus, 1 an, 2 beidseitig, 3 NUR Schatten (unsichtbar)
    r.u8()                       # receiveShadows
    r.u8(); r.u8(); r.u8()       # motionVectors, lightProbeUsage, reflectionProbeUsage
    r.align()
    lm_index = r.u16()
    lm_index_dyn = r.u16()
    lm_st = r.floats(4)
    r.floats(4)                  # dynamic tiling offset
    mats = r.pptrs()
    sb_first = r.u16()
    sb_count = r.u16()
    r.pptr()                     # static batch root
    r.pptr()                     # probe anchor
    r.pptr()                     # light probe volume override
    r.i32()                      # sorting layer id
    r.i16()                      # sorting layer
    r.i16()                      # sorting order
    r.align()
    return dict(go=go, enabled=enabled, cast_shadows=cast, lightmap_index=lm_index, lightmap_st=lm_st,
                materials=mats, sb_first=sb_first, sb_count=sb_count)


def read_meshrenderer(o):
    r = o.reader()
    d = _read_renderer_base(r)
    return d


def read_skinnedrenderer(o):
    r = o.reader()
    d = _read_renderer_base(r)
    r.i32()                      # quality
    r.bool(); r.bool()           # updateWhenOffscreen, skinnedMotionVectors
    r.align()
    d['mesh'] = r.pptr()
    d['bones'] = r.pptrs()
    return d


def read_lodgroup(o):
    r = o.reader()
    go = r.pptr()
    r.floats(3)        # local reference point
    r.f32()            # size
    r.i32()            # fade mode
    r.bool()           # animate cross fading
    r.align()
    lods = []
    for _ in range(r.count(64)):
        h = r.f32()
        r.f32()        # fade transition width
        rends = [r.pptr() for _ in range(r.count(10000))]
        lods.append(dict(height=h, renderers=rends))
    return dict(go=go, lods=lods)


def read_material(o):
    r = o.reader()
    name = r.string()
    shader = r.pptr()
    keywords = r.string()
    r.u32()                      # lightmap flags
    r.bool()                     # enable instancing variants
    r.align()
    queue = r.i32()
    tags = {}
    for _ in range(r.count(1000)):
        k = r.string()
        tags[k] = r.string()
    for _ in range(r.count(1000)):   # disabled shader passes
        r.string()
    texs = {}
    for _ in range(r.count(1000)):
        k = r.string()
        tex = r.pptr()
        sc = r.floats(2)
        off = r.floats(2)
        texs[k] = dict(tex=tex, scale=sc, offset=off)
    floats = {}
    for _ in range(r.count(1000)):
        k = r.string()
        floats[k] = r.f32()
    colors = {}
    for _ in range(r.count(1000)):
        k = r.string()
        colors[k] = r.floats(4)
    return dict(name=name, shader=shader, keywords=keywords.split(), queue=queue,
                tags=tags, textures=texs, floats=floats, colors=colors)


# ---- Texture2D ----------------------------------------------------------
TEXFMT = {1: 'Alpha8', 2: 'ARGB4444', 3: 'RGB24', 4: 'RGBA32', 5: 'ARGB32', 7: 'RGB565',
          9: 'R16', 10: 'DXT1', 12: 'DXT5', 13: 'RGBA4444', 14: 'BGRA32', 15: 'RHalf',
          16: 'RGHalf', 17: 'RGBAHalf', 18: 'RFloat', 19: 'RGFloat', 20: 'RGBAFloat',
          22: 'RGB9e5Float', 24: 'BC6H', 25: 'BC7', 26: 'BC4', 27: 'BC5',
          28: 'DXT1Crunched', 29: 'DXT5Crunched'}


def read_texture2d(o, env, want_data=True):
    r = o.reader()
    name = r.string()
    w, h = r.i32(), r.i32()
    r.i32()                      # complete image size
    fmt = r.i32()
    mips = r.i32()
    r.bool()                     # readable
    r.align()
    r.i32()                      # image count
    dim = r.i32()
    r.i32(); r.i32(); r.f32(); r.i32()   # filter, aniso, mipbias, wrap
    r.i32()                      # lightmap format
    r.i32()                      # color space
    size = r.i32()
    data = None
    if size > 0:
        data = r.b[r.p:r.p + size] if want_data else None
        r.p += size
        r.align()
        stream = None
    else:
        off = r.u32()
        ssize = r.u32()
        spath = r.string()
        stream = (spath, off, ssize)
        if want_data and ssize:
            data = env.read_stream(o.sf, spath, off, ssize)
    return dict(name=name, width=w, height=h, format=fmt, mips=mips, dim=dim,
                data=data, stream=stream)


def _bc_size(w, h, bpb):
    return max(1, (w + 3) // 4) * max(1, (h + 3) // 4) * bpb


# ---- Mesh ---------------------------------------------------------------
def _read_packed_float(r):
    n = r.u32(); rng = r.f32(); start = r.f32()
    data = r.bytes_arr()
    bits = r.u8(); r.align()
    return n, rng, start, data, bits


def _read_packed_int(r):
    n = r.u32()
    data = r.bytes_arr()
    bits = r.u8(); r.align()
    return n, data, bits


def _unpack_bits(data, n, bits):
    if n == 0 or bits == 0:
        return np.zeros(n, np.uint32)
    a = np.unpackbits(np.frombuffer(bytes(data), np.uint8), bitorder='little')
    a = a[:n * bits].reshape(n, bits).astype(np.uint32)
    return (a << np.arange(bits, dtype=np.uint32)).sum(1).astype(np.uint32)


def _unpack_float(pf):
    n, rng, start, data, bits = pf
    v = _unpack_bits(data, n, bits).astype(np.float64)
    mx = float((1 << bits) - 1) if bits else 1.0
    return (start + v * (rng / mx)).astype(np.float32)


CH_NAMES = ['position', 'normal', 'color', 'uv0', 'uv1', 'uv2', 'uv3', 'tangent']
FMT_SIZE = {0: 4, 1: 2, 2: 1, 3: 1, 4: 4}
FMT_DTYPE = {0: '<f4', 1: '<f2', 2: 'u1', 3: 'u1', 4: '<u4'}


def read_mesh(o):
    r = o.reader()
    name = r.string()
    subs = []
    for _ in range(r.count(100000)):
        fb, ic, topo, fv, vc = r.u32(), r.u32(), r.i32(), r.u32(), r.u32()
        r.floats(6)
        subs.append(dict(first_byte=fb, index_count=ic, topology=topo, first_vertex=fv, vertex_count=vc))
    # BlendShapes
    n = r.count(); r.p += n * 40
    n = r.count(); r.p += n * 12
    for _ in range(r.count()):
        r.string(); r.u32(); r.i32(); r.i32()
    n = r.count(); r.p += n * 4
    nbind = r.count()
    bindposes = np.frombuffer(r.b, '<f4', nbind * 16, r.p).reshape(nbind, 4, 4).copy() if nbind else None
    r.p += nbind * 64
    n = r.count(); r.p += n * 4  # bone name hashes
    r.u32()                      # root bone hash
    compression = r.u8()
    r.bool(); r.bool(); r.bool()
    r.align()
    ib = r.bytes_arr()
    nskin = r.count()
    skin = None
    if nskin:
        sk = np.frombuffer(r.b, np.uint8, nskin * 32, r.p)
        skin = sk
    r.p += nskin * 32
    # VertexData
    r.u32()                      # current channels
    vcount = r.u32()
    chans = []
    for _ in range(r.count(32)):
        chans.append((r.u8(), r.u8(), r.u8(), r.u8()))
    vdata = r.bytes_arr()

    out = dict(name=name, submeshes=subs, vertex_count=vcount, compression=compression)
    attrs = {}
    if vcount and len(vdata):
        nstreams = max(c[0] for c in chans if c[3] & 0xF) + 1 if any(c[3] & 0xF for c in chans) else 0
        strides = [0] * nstreams
        for i, (s, off, fmt, dim) in enumerate(chans):
            dim &= 0xF
            if dim:
                if i == 2 and fmt == 2 and dim == 1:
                    dim = 4
                strides[s] += FMT_SIZE.get(fmt, 4) * dim
        offsets, acc = [], 0
        for s in range(nstreams):
            offsets.append(acc)
            acc += strides[s] * vcount
            acc = (acc + 15) & ~15
        vb = np.frombuffer(bytes(vdata), np.uint8)
        for i, (s, off, fmt, dim) in enumerate(chans):
            dim &= 0xF
            if not dim or i >= len(CH_NAMES):
                continue
            if i == 2 and fmt == 2 and dim == 1:
                dim = 4
            es = FMT_SIZE.get(fmt, 4)
            stride = strides[s]
            base = offsets[s] + off
            need = base + (vcount - 1) * stride + es * dim
            if need > len(vb):
                print('    ! Mesh %s: Kanal %s ausserhalb Vertexdaten' % (name, CH_NAMES[i]))
                continue
            idx = base + np.arange(vcount)[:, None] * stride + np.arange(es * dim)[None, :]
            raw = vb[idx].reshape(-1)
            arr = np.frombuffer(raw.tobytes(), FMT_DTYPE.get(fmt, '<f4')).reshape(vcount, dim)
            if fmt in (2, 3):
                arr = arr.astype(np.float32) / 255.0
            attrs[CH_NAMES[i]] = arr.astype(np.float32)

    # CompressedMesh
    try:
        cm_v = _read_packed_float(r)
        cm_uv = _read_packed_float(r)
        cm_n = _read_packed_float(r)
        cm_t = _read_packed_float(r)
        _read_packed_int(r)          # weights
        cm_ns = _read_packed_int(r)
        _read_packed_int(r)          # tangent signs
        _read_packed_float(r)        # float colors
        _read_packed_int(r)          # bone indices
        cm_tri = _read_packed_int(r)
        r.u32()                      # uv info
    except Exception:
        cm_v = None
    if compression and cm_v is not None and cm_v[0]:
        vcount = cm_v[0] // 3
        out['vertex_count'] = vcount
        attrs['position'] = _unpack_float(cm_v).reshape(-1, 3)
        if cm_uv[0] >= vcount * 2:
            uv = _unpack_float(cm_uv)
            attrs['uv0'] = uv[:vcount * 2].reshape(-1, 2)
            if cm_uv[0] >= vcount * 4:
                attrs['uv1'] = uv[vcount * 2:vcount * 4].reshape(-1, 2)
        if cm_n[0] and cm_n[0] // 2 == vcount:
            nxy = _unpack_float(cm_n).reshape(-1, 2)
            signs = _unpack_bits(cm_ns[1], cm_ns[0], cm_ns[2])
            z = np.sqrt(np.clip(1 - (nxy ** 2).sum(1), 0, 1))
            z[signs == 0] *= -1
            attrs['normal'] = np.column_stack([nxy, z]).astype(np.float32)
        if cm_tri[0]:
            ib = _unpack_bits(cm_tri[1], cm_tri[0], cm_tri[2]).astype(np.uint32)
            out['indices32'] = ib
    if 'indices32' not in out:
        out['indices32'] = np.frombuffer(bytes(ib), '<u2').astype(np.uint32) if len(ib) else np.zeros(0, np.uint32)
    out['attrs'] = attrs
    out['bindposes'] = bindposes
    return out


def submesh_indices(mesh, i):
    """Dreiecksindizes eines Submeshes (Topologie 0=Triangles, 1=Strip)."""
    sm = mesh['submeshes'][i]
    ind = mesh['indices32']
    if mesh.get('compression'):
        # bei komprimierten Meshes zaehlt first_byte in 16bit-Indizes ebenfalls
        pass
    a = sm['first_byte'] // 2
    seg = ind[a:a + sm['index_count']]
    if sm['topology'] == 1:      # triangle strip
        tris = []
        for k in range(len(seg) - 2):
            a0, b0, c0 = int(seg[k]), int(seg[k + 1]), int(seg[k + 2])
            if a0 == b0 or b0 == c0 or a0 == c0:
                continue
            tris.append((a0, b0, c0) if k % 2 == 0 else (b0, a0, c0))
        return np.array(tris, np.uint32).reshape(-1, 3)
    if sm['topology'] != 0:
        return np.zeros((0, 3), np.uint32)
    n = len(seg) - len(seg) % 3
    return seg[:n].reshape(-1, 3)


# --------------------------------------------------------------------------
# Skybox: Cubemap -> Equirect-Panorama (.hdr) fuer Blender
# --------------------------------------------------------------------------

def _srgb_to_linear(a):
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)

def cubemap_to_equirect(faces, rotation_deg=0.0, height=1024):
    """Panorama direkt in Blenders Equirect-Konvention. rotation_deg = Unity _Rotation (um Y)."""
    H, W = height, height * 2
    w = faces[0].shape[0]
    j, i = np.mgrid[0:H, 0:W].astype(np.float32)
    phi = ((i + 0.5) / W - 0.5) * 2 * np.pi
    lat = np.pi / 2 - (j + 0.5) / H * np.pi
    cl = np.cos(lat)
    bx, by, bz = -np.cos(phi) * cl, np.sin(phi) * cl, np.sin(lat)       # Blender-Richtung
    dx, dy, dz = bx, bz, by                                             # -> Unity (x, z, y)
    a = np.radians(rotation_deg)
    dx, dz = np.cos(a) * dx - np.sin(a) * dz, np.sin(a) * dx + np.cos(a) * dz
    ax, ay, az = np.abs(dx), np.abs(dy), np.abs(dz)
    out = np.zeros((H, W, 3), np.float32)
    conds = [(ax >= ay) & (ax >= az) & (dx > 0), (ax >= ay) & (ax >= az) & (dx <= 0),
             (ay > ax) & (ay >= az) & (dy > 0), (ay > ax) & (ay >= az) & (dy <= 0),
             (az > ax) & (az > ay) & (dz > 0), (az > ax) & (az > ay) & (dz <= 0)]
    sct = [(-dz, -dy, ax), (dz, -dy, ax), (dx, dz, ay), (dx, -dz, ay), (dx, -dy, az), (-dx, -dy, az)]
    for fi, (c, (sc, tc, ma)) in enumerate(zip(conds, sct)):
        u = (sc[c] / ma[c] + 1) * 0.5 * w - 0.5
        v = (tc[c] / ma[c] + 1) * 0.5 * w - 0.5
        x0 = np.clip(np.floor(u).astype(int), 0, w - 1); x1 = np.clip(x0 + 1, 0, w - 1)
        y0 = np.clip(np.floor(v).astype(int), 0, w - 1); y1 = np.clip(y0 + 1, 0, w - 1)
        fx = np.clip(u - x0, 0, 1)[:, None]; fy = np.clip(v - y0, 0, 1)[:, None]
        F = faces[fi]
        out[c] = ((F[y0, x0] * (1 - fx) + F[y0, x1] * fx) * (1 - fy) +
                  (F[y1, x0] * (1 - fx) + F[y1, x1] * fx) * fy)
    return out


def write_hdr(path, img):
    """Radiance .hdr (RGBE, unkomprimiert)."""
    h, w, _ = img.shape
    v = np.maximum(img.max(axis=2), 1e-32)
    m, e = np.frexp(v)
    scale = np.where(v > 1e-32, m * 256.0 / v, 0)
    rgbe = np.zeros((h, w, 4), np.uint8)
    rgbe[..., :3] = np.clip(img * scale[..., None], 0, 255).astype(np.uint8)
    rgbe[..., 3] = np.where(v > 1e-32, e + 128, 0).astype(np.uint8)
    with open(path, 'wb') as f:
        f.write(b'#?RADIANCE\nFORMAT=32-bit_rle_rgbe\n\n-Y %d +X %d\n' % (h, w))
        f.write(rgbe.tobytes())


def read_skybox_material_pptr(sf):
    """RenderSettings (5.6): Fog, Ambient-Farben, SubtractiveShadowColor, dann m_SkyboxMaterial."""
    for o in sf.by_class(104):
        r = o.reader()
        r.bool(); r.align()          # m_Fog
        r.floats(4); r.i32(); r.floats(3)        # FogColor, FogMode, Density, Start, End
        r.floats(12); r.f32(); r.i32()           # Ambient Sky/Equator/Ground, Intensity, Mode
        r.floats(4)                              # SubtractiveShadowColor
        return r.pptr()
    return None


# --------------------------------------------------------------------------
# Hilfen: Matrizen
# --------------------------------------------------------------------------
def trs_matrix(pos, rot, scl):
    x, y, z, w = rot
    m = np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]], np.float64)
    M = np.eye(4)
    M[:3, :3] = m * np.array(scl)[None, :]
    M[:3, 3] = pos
    return M


def safe_name(s, maxlen=80):
    s = re.sub(r'[^\w\-. ]+', '_', s).strip()
    return (s or 'noname')[:maxlen]


