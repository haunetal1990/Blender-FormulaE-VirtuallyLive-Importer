# -*- coding: utf-8 -*-
"""Crunch (.crn, alte Version wie in Unity 5.6) -> DXT1/DXT5-Bloecke. Reines Python.
Portiert aus crn_decomp.h (crunch v1.04, Public Domain / zlib)."""
try:
    import numpy as np
except ImportError:  # pragma: no cover
    np = None

_DXT1_FROM_LINEAR = (0, 2, 3, 1)
_DXT5_FROM_LINEAR = (0, 2, 3, 4, 5, 6, 7, 1)
_TILES = ((0, 0, 0, 0), (0, 0, 1, 1), (0, 1, 0, 1), (0, 0, 1, 2), (1, 2, 0, 0),
          (0, 1, 0, 2), (1, 0, 2, 0), (0, 1, 2, 3))
_NUM_TILES = (1, 2, 2, 3, 3, 3, 3, 4)
_MOST_PROBABLE = (17, 18, 19, 20, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15, 16)


class CrunchError(Exception):
    pass


class _Bits:
    """MSB-first Bitleser ueber einem Byte-Segment (nach dem Ende: Nullen)."""
    __slots__ = ('win', 'pos')

    def __init__(self, data):
        b = bytes(data) + b'\0\0\0\0\0'
        if np is not None:
            a = np.frombuffer(b, np.uint8).astype(np.uint32)
            w = (a[:-3] << 24) | (a[1:-2] << 16) | (a[2:-1] << 8) | a[3:]
            self.win = w.tolist()
        else:
            self.win = [int.from_bytes(b[i:i + 4], 'big') for i in range(len(b) - 3)]
        self.pos = 0

    def bits(self, n):
        if n == 0:
            return 0
        if n > 16:
            hi = self.bits(n - 16)
            return (hi << 16) | self.bits(16)
        p = self.pos
        v = (self.win[p >> 3] >> (32 - (p & 7) - n)) & ((1 << n) - 1)
        self.pos = p + n
        return v


class _Model:
    """Kanonischer Huffman-Decoder ueber eine 16-Bit-Lookup-Tabelle: Eintrag = sym << 5 | laenge."""
    __slots__ = ('table', 'nsyms')

    def __init__(self, sizes):
        self.nsyms = len(sizes)
        self.table = None
        if not sizes:
            return
        maxlen = max(sizes) if sizes else 0
        if maxlen == 0:
            return
        if maxlen > 16:
            raise CrunchError('Codelaenge > 16')
        num = [0] * 17
        for s in sizes:
            if s:
                num[s] += 1
        nextcode = [0] * 18
        code = 0
        for L in range(1, 17):
            nextcode[L] = code
            code = (code + num[L]) << 1
        table = [0] * 65536
        for sym, L in enumerate(sizes):
            if not L:
                continue
            c = nextcode[L]
            nextcode[L] += 1
            start = c << (16 - L)
            n = 1 << (16 - L)
            table[start:start + n] = [(sym << 5) | L] * n
        self.table = table


def _decode(bits, model):
    p = bits.pos
    e = model.table[(bits.win[p >> 3] >> (16 - (p & 7))) & 0xFFFF]
    bits.pos = p + (e & 31)
    return e >> 5


def _receive_model(bits):
    total = bits.bits(14)          # math::total_bits(cMaxSupportedSyms=8192) = 14
    if not total:
        return _Model([])
    sizes = [0] * total
    n = bits.bits(5)
    if n < 1 or n > 21:
        raise CrunchError('ungueltige Codelaengen-Anzahl')
    cl = [0] * 21
    for i in range(n):
        cl[_MOST_PROBABLE[i]] = bits.bits(3)
    dm = _Model(cl)
    ofs = 0
    while ofs < total:
        code = _decode(bits, dm)
        if code <= 16:
            sizes[ofs] = code
            ofs += 1
        elif code == 17:
            ofs += bits.bits(3) + 3
        elif code == 18:
            ofs += bits.bits(7) + 11
        elif code in (19, 20):
            ln = bits.bits(2) + 3 if code == 19 else bits.bits(6) + 7
            if not ofs:
                raise CrunchError('Wiederholung ohne Vorgaenger')
            prev = sizes[ofs - 1]
            for k in range(ln):
                sizes[ofs + k] = prev
            ofs += ln
        else:
            raise CrunchError('ungueltiger Codelaengen-Code')
    if ofs != total:
        raise CrunchError('Codelaengen-Ueberlauf')
    return _Model(sizes)


def _be(b, o, n):
    return int.from_bytes(b[o:o + n], 'big')


def parse_header(data):
    b = bytes(data[:80])
    if _be(b, 0, 2) != 0x4878:
        raise CrunchError('keine Crunch-Daten (Signatur)')
    h = dict(header_size=_be(b, 2, 2), width=_be(b, 12, 2), height=_be(b, 14, 2), levels=b[16], faces=b[17],
             format=b[18], flags=_be(b, 19, 2))
    for k, name in enumerate(('color_endpoints', 'color_selectors', 'alpha_endpoints', 'alpha_selectors')):
        o = 33 + 8 * k
        h[name] = (_be(b, o, 3), _be(b, o + 3, 3), _be(b, o + 6, 2))     # ofs, size, num
    h['tables_size'] = _be(b, 65, 2)
    h['tables_ofs'] = _be(b, 67, 3)
    h['level_ofs'] = [_be(bytes(data), 70 + 4 * i, 4) for i in range(h['levels'])]
    return h


def unpack_level(data, level=0):
    """-> (format 'DXT1'|'DXT5', width, height, bytes der DXT-Bloecke dieser Mip-Stufe, Face 0)."""
    data = bytes(data)
    h = parse_header(data)
    fmt = h['format']
    if fmt not in (0, 2):
        raise CrunchError('Crunch-Format %d nicht unterstuetzt' % fmt)
    dxt5 = fmt == 2
    # Tabellen
    tb = _Bits(data[h['tables_ofs']:h['tables_ofs'] + h['tables_size']])
    chunk_dm = _receive_model(tb)
    ep_dm = [None, None]
    sel_dm = [None, None]
    if h['color_endpoints'][2]:
        ep_dm[0] = _receive_model(tb)
        sel_dm[0] = _receive_model(tb)
    if h['alpha_endpoints'][2]:
        ep_dm[1] = _receive_model(tb)
        sel_dm[1] = _receive_model(tb)

    # Paletten ------------------------------------------------------------
    color_eps = []
    color_sels = []
    alpha_eps = []
    alpha_sels = []
    ofs, size, num = h['color_endpoints']
    if num:
        bb = _Bits(data[ofs:ofs + size])
        d0, d1 = _receive_model(bb), _receive_model(bb)
        a = b_ = c = d = e = f = 0
        app = color_eps.append
        for _ in range(num):
            a = (a + _decode(bb, d0)) & 31
            b_ = (b_ + _decode(bb, d1)) & 63
            c = (c + _decode(bb, d0)) & 31
            d = (d + _decode(bb, d0)) & 31
            e = (e + _decode(bb, d1)) & 63
            f = (f + _decode(bb, d0)) & 31
            app(c | (b_ << 5) | (a << 11) | (f << 16) | (e << 21) | (d << 27))
        ofs, size, num = h['color_selectors']
        bb = _Bits(data[ofs:ofs + size])
        dm = _receive_model(bb)
        cur = [0] * 16
        fl = _DXT1_FROM_LINEAR
        app = color_sels.append
        for _ in range(num):
            for j in range(8):
                sym = _decode(bb, dm)
                cur[2 * j] = (cur[2 * j] + (sym % 7) - 3) & 3
                cur[2 * j + 1] = (cur[2 * j + 1] + (sym // 7) - 3) & 3
            v = 0
            for k in range(16):
                v |= fl[cur[k]] << (2 * k)
            app(v)
    ofs, size, num = h['alpha_endpoints']
    if num:
        bb = _Bits(data[ofs:ofs + size])
        dm = _receive_model(bb)
        a = b_ = 0
        for _ in range(num):
            a = (a + _decode(bb, dm)) & 255
            b_ = (b_ + _decode(bb, dm)) & 255
            alpha_eps.append(a | (b_ << 8))
        ofs, size, num = h['alpha_selectors']
        bb = _Bits(data[ofs:ofs + size])
        dm = _receive_model(bb)
        cur = [0] * 16
        fl = _DXT5_FROM_LINEAR
        for _ in range(num):
            for j in range(8):
                sym = _decode(bb, dm)
                cur[2 * j] = (cur[2 * j] + (sym % 15) - 7) & 7
                cur[2 * j + 1] = (cur[2 * j + 1] + (sym // 15) - 7) & 7
            v = 0
            for k in range(16):
                v |= fl[cur[k]] << (3 * k)              # 48 Bit Selektoren
            alpha_sels.append(v)

    # Level 0 --------------------------------------------------------------
    level = max(0, min(level, h['levels'] - 1))
    w, hgt = max(1, h['width'] >> level), max(1, h['height'] >> level)
    bx_n, by_n = (w + 3) >> 2, (hgt + 3) >> 2
    cx_n, cy_n = (bx_n + 1) >> 1, (by_n + 1) >> 1
    lo = h['level_ofs'][level]
    hi = h['level_ofs'][level + 1] if level + 1 < h['levels'] else len(data)
    bits = _Bits(data[lo:hi])
    win = bits.win
    nce, ncs = len(color_eps), len(color_sels)
    nae, nas = len(alpha_eps), h['alpha_selectors'][2]
    pce = pcs = pae = pas = 0
    chunk_bits = 1
    ct, e0t, s0t = chunk_dm.table, ep_dm[0].table, sel_dm[0].table
    e1t = ep_dm[1].table if dxt5 else None
    s1t = sel_dm[1].table if dxt5 else None
    nblocks = bx_n * by_n
    out_lo = [0] * nblocks           # DXT1: Endpunkte / DXT5: Alpha-Teil (64 Bit)
    out_hi = [0] * nblocks           # Selektoren / DXT5: Farbteil (64 Bit)
    pos = bits.pos
    for cy in range(cy_n):
        xs = range(cx_n) if not (cy & 1) else range(cx_n - 1, -1, -1)
        skip_bottom = (cy == cy_n - 1) and (by_n & 1)
        for cx in xs:
            if chunk_bits == 1:
                e = ct[(win[pos >> 3] >> (16 - (pos & 7))) & 0xFFFF]; pos += e & 31
                chunk_bits = (e >> 5) | 512
            enc = chunk_bits & 7
            chunk_bits >>= 3
            nt = _NUM_TILES[enc]
            tiles = _TILES[enc]
            skip_right = (bx_n & 1) and (cx == cx_n - 1)
            if dxt5:
                aeps = [0, 0, 0, 0]
                for i in range(nt):
                    e = e1t[(win[pos >> 3] >> (16 - (pos & 7))) & 0xFFFF]; pos += e & 31
                    pae += e >> 5
                    if pae >= nae:
                        pae -= nae
                    aeps[i] = alpha_eps[pae]
            ceps = [0, 0, 0, 0]
            for i in range(nt):
                e = e0t[(win[pos >> 3] >> (16 - (pos & 7))) & 0xFFFF]; pos += e & 31
                pce += e >> 5
                if pce >= nce:
                    pce -= nce
                ceps[i] = color_eps[pce]
            for by in range(2):
                for bx in range(2):
                    if dxt5:
                        e = s1t[(win[pos >> 3] >> (16 - (pos & 7))) & 0xFFFF]; pos += e & 31
                        pas += e >> 5
                        if pas >= nas:
                            pas -= nas
                    e = s0t[(win[pos >> 3] >> (16 - (pos & 7))) & 0xFFFF]; pos += e & 31
                    pcs += e >> 5
                    if pcs >= ncs:
                        pcs -= ncs
                    if (bx and skip_right) or (by and skip_bottom):
                        continue
                    t = tiles[bx + by * 2]
                    bi = (cy * 2 + by) * bx_n + cx * 2 + bx
                    if dxt5:
                        out_lo[bi] = aeps[t] | (alpha_sels[pas] << 16)
                        out_hi[bi] = ceps[t] | (color_sels[pcs] << 32)
                    else:
                        out_lo[bi] = ceps[t]
                        out_hi[bi] = color_sels[pcs]
    if np is None:
        raise CrunchError('numpy fehlt')
    if dxt5:
        blk = np.empty((nblocks, 2), np.uint64)
        blk[:, 0] = np.array(out_lo, np.uint64)
        blk[:, 1] = np.array(out_hi, np.uint64)
    else:
        blk = np.empty((nblocks, 2), np.uint32)
        blk[:, 0] = np.array(out_lo, np.uint32)
        blk[:, 1] = np.array(out_hi, np.uint32)
    return ('DXT5' if dxt5 else 'DXT1'), w, hgt, blk.astype(blk.dtype.newbyteorder('<')).tobytes()
