"""Core of the Formula E VLive importer: Unity parsing, texture decoding, scene collection.
Must not import bpy (also runs in worker processes)."""
