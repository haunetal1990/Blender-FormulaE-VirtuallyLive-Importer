# -*- coding: utf-8 -*-
"""Parallel texture decoding (process pool). No bpy here."""
import os
import sys
import time

from . import unity as U
from . import textures as T

_env = None
_tc = None


def init(data_dir, cache_dir, max_size):
    global _env, _tc
    _env = U.Environment(data_dir)
    _tc = T.TextureCache(_env, cache_dir, max_size=max_size, log=lambda m: None)


def run(job):
    """job = (kind, file, path_id, normal) -> (job, result, failures)"""
    kind, fname, pid, normal = job
    _tc.failed = []
    try:
        sf = _env.get(fname)
        o = sf.objects.get(pid) if sf else None
        if o is None:
            return job, None, ['%s:%d (object not found)' % (fname, pid)]
        res = _tc.array_layers(o) if kind == 'arr' else _tc.texture(o, normal=normal)
        return job, res, list(_tc.failed)
    except Exception as ex:
        return job, None, ['%s:%d (%s)' % (fname, pid, ex)]


def plan_jobs(materials, tc):
    """All textures used by the given material definitions that are not cached yet.
    -> list of jobs, biggest first."""
    jobs = {}
    for d in materials:
        for t in d.get('textures', {}).values():
            o = t['obj']
            if 'layer' in t:
                job = ('arr', o.sf.name, o.path_id, False)
            else:
                job = ('tex', o.sf.name, o.path_id, bool(t.get('normal')))
            if job in jobs:
                continue
            if job[0] == 'tex' and tc.cached_path(o, job[3]):
                continue
            jobs[job] = o.size
    return [j for j, _ in sorted(jobs.items(), key=lambda x: -x[1])]


def _python_exe():
    exe = sys.executable or ''
    if exe and 'blender' not in os.path.basename(exe).lower() and os.path.isfile(exe):
        return exe
    return None


# Worker processes are plain Python (no bpy, no Blender package tree), so they cannot import this
# add-on by its package name (bl_ext.<repo>.io_import_vlive...).  Instead the pool is started with
# builtins only: the initializer exec()s a few lines that make the add-on folder importable *inside
# the worker process* and import vlivecore there as a top-level package; each task is an eval() of
# a call to the function registered by that initializer.  Blender's own sys.path / sys.modules stay
# untouched (extension policy).
_BOOT = '''
import builtins, sys
sys.path.insert(0, %r)
from vlivecore import worker as _w
_w.init(%r, %r, %r)
builtins._vlive_run = _w.run
'''
_ADDON_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def decode_parallel(jobs, data_dir, cache_dir, max_size, workers, progress=None, log=print):
    """Decode in worker processes. -> dict job -> (result, failures); None if the pool is not usable."""
    if not jobs:
        return {}
    exe = _python_exe()
    if exe is None or workers < 2 or len(jobs) < 3:
        return None
    import multiprocessing as mp
    from concurrent.futures import ProcessPoolExecutor, as_completed
    ctx = mp.get_context('spawn')
    try:
        ctx.set_executable(exe)
    except Exception:
        pass
    out = {}
    t0 = time.time()
    try:
        boot = _BOOT % (_ADDON_DIR, data_dir, cache_dir, max_size)
        with ProcessPoolExecutor(max_workers=workers, mp_context=ctx, initializer=exec,
                                 initargs=(boot,)) as ex:
            futs = [ex.submit(eval, '_vlive_run(job)', {'job': j}) for j in jobs]
            for i, f in enumerate(as_completed(futs)):
                job, res, fails = f.result()
                out[job] = (res, fails)
                if progress and (i % 5 == 0 or i + 1 == len(jobs)):
                    progress((i + 1) / len(jobs), 'Textures %d/%d (%d processes, %.0f s)'
                             % (i + 1, len(jobs), workers, time.time() - t0))
    except Exception as ex:
        log('  parallel decoding not available (%s) - continuing in one process' % ex)
        return None
    return out
