# -*- coding: utf-8 -*-
"""Blender-Seite: Meshes, Materialien, World aus den gesammelten Szenendaten bauen."""
import os
import re
import time

import numpy as np
import bpy
from mathutils import Matrix

# Optionen (werden vom Import-Operator gesetzt)
LOD0_ONLY = True
INACTIVE_MODE = 'HIDDEN'      # HIDDEN: own hidden collections | SKIP | VISIBLE
VERTEX_COLOR_STRENGTH = 1.0
IMPORT_SKY = True
SKY_STRENGTH = 1.0
SKIP_SHADOW_ONLY = True
IMPORT_NORMALS = True
SCALE = 1.0

UV_LAYER_NAMES = ('UVMap', 'UV1', 'UV2', 'UV3')

# Unity -> Blender: Y und Z vertauschen (Spiegelung = Wechsel der Haendigkeit)
P = np.array([[1, 0, 0, 0],
              [0, 0, 1, 0],
              [0, 1, 0, 0],
              [0, 0, 0, 1]], np.float64)


# --------------------------------------------------------------------------
# Reine numpy-Logik (ohne bpy)
# --------------------------------------------------------------------------
def build_geometry(data, static_batch=None):
    """
    data: Inhalt der .npz,  static_batch: [first, count] oder None
    -> dict(V, F, mat_index, attrs{name: per-vertex array}) in Blender-Koordinaten.
    """
    meta = data['meta']
    nsub = meta['submeshes']
    rng = range(nsub)
    if static_batch:
        a, c = static_batch
        rng = range(a, min(a + c, nsub))
    tris, mats = [], []
    for local_i, si in enumerate(rng):
        t = data.get('sub%d' % si)
        if t is None or t.size == 0:
            continue
        tris.append(t)
        mats.append(np.full(len(t), local_i, np.int32))
    if not tris:
        return None
    F = np.concatenate(tris).astype(np.int64)
    M = np.concatenate(mats)
    inside = (F < len(data['position'])).all(1)
    if not inside.all():
        F, M = F[inside], M[inside]
    if not len(F):
        return None
    used = np.unique(F)
    remap = np.full(len(data['position']), -1, np.int64)
    remap[used] = np.arange(len(used))
    # mirrored axes flip the winding -> swap; drop degenerate triangles (saves mesh.validate())
    F = remap[F][:, [0, 2, 1]]
    ok = (F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])
    if not ok.all():
        F, M = F[ok], M[ok]
    if not len(F):
        return None
    attrs = {}
    for k in ('position', 'normal', 'tangent', 'color', 'uv0', 'uv1', 'uv2', 'uv3'):
        if k in data and len(data[k]) == len(data['position']):
            attrs[k] = data[k][used]
    V = attrs.pop('position')[:, :3].astype(np.float64)
    V = V[:, [0, 2, 1]] * SCALE
    if 'normal' in attrs:
        n = attrs['normal'][:, :3].astype(np.float64)[:, [0, 2, 1]]
        ln = np.linalg.norm(n, axis=1, keepdims=True)
        ln[ln == 0] = 1
        attrs['normal'] = n / ln
    return dict(V=V, F=F, mat_index=M, attrs=attrs, name=meta.get('name', ''))


def unity_world_to_blender(world):
    Mu = np.asarray(world, np.float64).reshape(4, 4)
    Mb = P @ Mu @ P
    Mb[:3, 3] *= SCALE
    return Mb


def has_shear(Mb, tol=1e-4):
    """True, wenn die 3x3-Matrix nicht als Rotation*Skalierung darstellbar ist (Blender-Objekte koennen keine Scherung)."""
    A = Mb[:3, :3]
    G = A.T @ A
    d = np.sqrt(np.abs(np.diag(G))) + 1e-12
    off = G / np.outer(d, d) - np.eye(3)
    return np.abs(off).max() > tol


def bake_matrix(geo, Mb):
    """Matrix in Vertices/Normalen einrechnen; zurueck bleibt nur die Translation fuer das Objekt."""
    A = Mb[:3, :3]
    geo = dict(geo)
    geo['V'] = geo['V'] @ A.T
    at = dict(geo['attrs'])
    if 'normal' in at:
        n = at['normal'] @ np.linalg.inv(A)       # (A^-T n) zeilenweise
        ln = np.linalg.norm(n, axis=1, keepdims=True)
        ln[ln == 0] = 1
        at['normal'] = n / ln
    geo['attrs'] = at
    if np.linalg.det(A) < 0:                         # gespiegelt -> Windung zurueckdrehen
        geo['F'] = geo['F'][:, [0, 2, 1]]
    T = np.eye(4)
    T[:3, 3] = Mb[:3, 3]
    return geo, T


def is_inactive(node):
    return not node.get('active', True) or not node.get('renderer_enabled', True)


GROUP_SEG = re.compile(r'^(Group_\d+_\w+|-?mesh)$', re.I)


def inactive_group(nodes, idx):
    """Name for the hidden collection of an inactive object: path of the topmost switched-off
    ancestor (MeshBaker 'Group_N_Renderer' / '-mesh' levels folded into their parent)."""
    nd = nodes[idx]
    if nd.get('active', True):
        return 'Renderer disabled'
    j = idx
    while nodes[j]['parent'] >= 0 and not nodes[nodes[j]['parent']].get('active', True):
        j = nodes[j]['parent']
    segs = nodes[j]['path'].split('/')
    while len(segs) > 1 and GROUP_SEG.match(segs[-1]):
        segs.pop()
    if len(segs) > 1:
        segs = segs[1:]                               # drop the scene root ('World')
    return clean_name('/'.join(segs[-2:]))


def node_filter(node):
    if 'mesh' not in node:
        return False
    if is_inactive(node) and INACTIVE_MODE == 'SKIP':
        return False
    if LOD0_ONLY and node.get('lod', 0) > 0:
        return False
    if SKIP_SHADOW_ONLY and node.get('cast_shadows') == 3:
        return False
    return True


GENERIC_NAME = re.compile(r'^(-?mesh(\.\d+)?|.*-mesh(\.\d+)?|combined mesh.*|[0-9a-f]{32}(\s*\(clone\))*|'
                          r'gameobject|new game object|merged\s*\d*|cube|plane|quad|object\d*|)$', re.I)


def is_generic(name):
    return bool(GENERIC_NAME.match(clean_name(name)))


UNITY_DUP = re.compile(r'(\s*\(clone\))+\s*$|\s*\(\d+\)\s*$', re.I)


def clean_name(name):
    """'Boxes_light_emitter (2)' / 'Tree(Clone)' -> 'Boxes_light_emitter' / 'Tree' (Blender haengt .001 an)."""
    prev = None
    name = (name or '').strip()
    while prev != name:
        prev = name
        name = UNITY_DUP.sub('', name).strip()
    return name or 'mesh'


def object_name(nd, matb):
    return clean_name(_object_name(nd, matb))


def _object_name(nd, matb):
    """Sprechender Name: GameObject-Name, sonst Mesh-Name, sonst Material + naechster sinnvoller Elternname."""
    go = nd.get('name', '')
    if not is_generic(go):
        return go
    mesh = nd.get('mesh_name', '')
    if not is_generic(mesh):
        return mesh.replace('(Clone)', '').strip()
    mat = ''
    for mk in nd.get('materials', []):
        if mk and mk in matb.defs:
            mat = matb.defs[mk].get('name', '')
            if mat:
                break
    parent = next((p for p in reversed(nd.get('path', '').split('/')[:-1]) if not is_generic(p)), '')
    parts = [x for x in (parent, mat) if x]
    return '_'.join(parts) or go or 'mesh'


# --------------------------------------------------------------------------
# Blender-Teil
# --------------------------------------------------------------------------
def _socket(node, *names):
    for n in names:
        if n in node.inputs:
            return node.inputs[n]
    return None


class MaterialBuilder:
    """Materialien aus den Szenendaten; Bilder kommen aus dem TextureCache (PNG-Dateien)."""

    def __init__(self, texcache, defs, pack=False):
        self.tc = texcache
        self.defs = defs
        self.pack = pack
        self.mats = {}
        self.images = {}

    def _load(self, path, non_color):
        key = (path, non_color)
        if key in self.images:
            return self.images[key]
        img = None
        if path and os.path.isfile(path):
            try:
                img = bpy.data.images.load(path, check_existing=True)
                if non_color:
                    img.colorspace_settings.name = 'Non-Color'
                    img.alpha_mode = 'CHANNEL_PACKED'      # masks/metallic: RGB must not be touched by alpha
                else:
                    img.alpha_mode = 'STRAIGHT'
                if self.pack and not img.packed_file:
                    img.pack()
            except Exception as ex:
                print('[VLive] image could not be loaded:', path, ex)
        self.images[key] = img
        return img

    def image(self, t, non_color=False):
        """t = Textureintrag aus der Materialdefinition"""
        o = t['obj']
        if 'layer' in t:
            layers = self.tc.array_layers(o)
            path = layers[t['layer']] if t['layer'] < len(layers) else None
            return self._load(path, non_color)
        res = self.tc.texture(o, normal=t.get('normal', False))
        return self._load(res[0] if res else None, non_color)

    def get(self, key, force_decal=False):
        if key is None:
            key = '__default__'
        ck = key + ('#decal' if force_decal else '')
        if ck in self.mats:
            return self.mats[ck]
        d = self.defs.get(key, dict(name='default', textures={}, colors={}, floats={}))
        mat = bpy.data.materials.new((d.get('name') or key) + ('_decal' if force_decal else ''))
        mat.use_nodes = True
        mat['unity_shader'] = d.get('shader', '')
        mat['unity_keywords'] = ' '.join(d.get('keywords', []))
        mat['unity_material'] = key
        kit = NodeKit(self, mat, d)
        kit.force_decal = force_decal
        kind = material_kind(d)
        if force_decal and kind == 'layered':
            kind = 'standard'
        mat['vlive_type'] = kind
        if kind == 'splat':
            kit.build_splat()
        elif kind == 'layered':
            kit.build_layered()
        elif kind == 'water':
            kit.build_water()
        else:
            kit.build_standard(tree=(kind == 'tree'))
        self.mats[ck] = mat
        return mat


CUTOUT_NAMES = re.compile(r'tree|palm|leaf|leaves|frond|bush|plant|foliage|vegetation|people|crowd|fence_?trans')
DECAL_NAMES = re.compile(r'decal|stain|tiremark|skidmark', re.I)


def material_kind(d):
    """Shader-Typ anhand Name UND Textur-Slots (Shader liegen oft in resources.assets)."""
    texs = d.get('textures', {})
    sh = (d.get('shader') or '').lower()
    slots = set(texs) | set(d.get('slots', []))
    name = (d.get('name') or '').lower()
    if 'distingo' in sh or 'terrain splat' in sh or '_Splat0' in slots:
        return 'splat'
    if any(s.startswith(('_DefaultBC', '_RBC', '_GBC', '_BBC', '_RArr', '_GArr', '_BArr')) for s in slots) \
            or 'seamlessvcmask' in sh:
        return 'layered'
    if slots & {'_LargeWavesTexture', '_MediumWavesTexture', '_SmallWavesTexture', '_FoamTexture'} \
            or 'aquas' in sh or 'water' in sh or (name.endswith('water') and '_MainTex' not in texs):
        return 'water'
    kw = set(d.get('keywords', []))
    if 'speedtree' in sh or any(k.startswith('GEOM_TYPE_') for k in kw):
        return 'tree'
    return 'standard'


class NodeKit:
    """Hilfsfunktionen zum Aufbau der Node-Baeume."""

    def __init__(self, mb, mat, d):
        self.mb = mb
        self.mat = mat
        self.d = d
        self.nt = mat.node_tree
        self.texs = d.get('textures', {})
        self.cols = d.get('colors', {})
        self.fl = d.get('floats', {})
        self.kw = set(d.get('keywords', []))
        nt = self.nt
        self.bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        out = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if self.bsdf is None:
            self.bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            nt.links.new(self.bsdf.outputs[0], out.inputs[0])
        self.uv_nodes = {}
        self.vc = None
        self.y = 600
        self.main_st = None
        self.force_decal = False

    # -- Grundbausteine
    def link(self, a, b):
        self.nt.links.new(a, b)

    def uv(self, idx):
        idx = int(idx)
        name = UV_LAYER_NAMES[idx] if 0 <= idx < len(UV_LAYER_NAMES) else UV_LAYER_NAMES[0]
        if name not in self.uv_nodes:
            n = self.nt.nodes.new('ShaderNodeUVMap')
            n.uv_map = name
            n.location = (-1500, 300 - 150 * len(self.uv_nodes))
            self.uv_nodes[name] = n
        return self.uv_nodes[name].outputs['UV']

    def tex(self, slot, non_color=False, uv=0, st=None):
        t = self.texs.get(slot)
        if not t:
            return None
        img = self.mb.image(t, non_color)
        if img is None:
            return None
        n = self.nt.nodes.new('ShaderNodeTexImage')
        n.image = img
        n.label = slot
        n.location = (-1000, self.y)
        self.y -= 280
        if st is None:
            st = (t.get('scale', [1, 1]), t.get('offset', [0, 0]))
        sc, off = st
        if sc != [1, 1] or off != [0, 0] or int(uv) != 0:
            mp = self.nt.nodes.new('ShaderNodeMapping')
            mp.location = (-1250, n.location[1])
            mp.inputs['Scale'].default_value = (sc[0], sc[1], 1)
            mp.inputs['Location'].default_value = (off[0], off[1], 0)
            self.link(self.uv(uv), mp.inputs['Vector'])
            self.link(mp.outputs['Vector'], n.inputs['Vector'])
        return n

    def tex_box(self, slot, scale, non_color=False):
        """Image texture with box (triplanar) projection on world coordinates * scale."""
        n = self.tex(slot, non_color, st=([1, 1], [0, 0]))
        if n is None:
            return None
        n.projection = 'BOX'
        n.projection_blend = 0.3
        if not hasattr(self, '_geo'):
            self._geo = self.nt.nodes.new('ShaderNodeNewGeometry')
            self._geo.location = (-1500, -400)
        mp = self.nt.nodes.new('ShaderNodeMapping')
        mp.location = (-1250, n.location[1])
        scale = scale / (SCALE or 1.0)              # Blender world = Unity world * SCALE
        mp.inputs['Scale'].default_value = (scale, scale, scale)
        self.link(self._geo.outputs['Position'], mp.inputs['Vector'])
        self.link(mp.outputs['Vector'], n.inputs['Vector'])
        return n

    def mix(self, blend='MIX', fac=None, a=None, b=None):
        """RGBA-Mix; a/b/fac duerfen Sockets oder Werte sein. -> Ausgangs-Socket"""
        try:
            m = self.nt.nodes.new('ShaderNodeMix')
            m.data_type = 'RGBA'
            m.blend_type = blend
            fi, ai, bi, out = m.inputs[0], m.inputs[6], m.inputs[7], m.outputs[2]
        except Exception:
            m = self.nt.nodes.new('ShaderNodeMixRGB')
            m.blend_type = blend
            fi, ai, bi, out = m.inputs[0], m.inputs[1], m.inputs[2], m.outputs[0]
        m.location = (-600, self.y)
        self.y -= 40
        for sock, v in ((fi, fac), (ai, a), (bi, b)):
            if v is None:
                continue
            if hasattr(v, 'is_output'):
                self.link(v, sock)
            else:
                sock.default_value = v
        if fac is None:
            fi.default_value = 1.0
        return out

    def math(self, op, a, b=None, c=None, clamp=False):
        n = self.nt.nodes.new('ShaderNodeMath')
        n.operation = op
        n.use_clamp = clamp
        n.location = (-400, self.y)
        for i, v in enumerate((a, b, c)):
            if v is None:
                continue
            if hasattr(v, 'is_output'):
                self.link(v, n.inputs[i])
            else:
                n.inputs[i].default_value = v
        return n.outputs[0]

    def separate(self, sock):
        if hasattr(bpy.types, 'ShaderNodeSeparateColor'):
            n = self.nt.nodes.new('ShaderNodeSeparateColor')
        else:
            n = self.nt.nodes.new('ShaderNodeSeparateRGB')
        n.location = (-800, self.y)
        self.link(sock, n.inputs[0])
        return n.outputs[0], n.outputs[1], n.outputs[2]

    def vertex_color(self):
        if self.vc is None:
            try:
                n = self.nt.nodes.new('ShaderNodeVertexColor')
                n.layer_name = 'Col'
            except Exception:
                n = self.nt.nodes.new('ShaderNodeAttribute')
                n.attribute_name = 'Col'
            n.location = (-1500, -600)
            self.vc = n
        return self.vc.outputs['Color']

    def vertex_alpha(self):
        try:
            self.vertex_color()
            return self.vc.outputs['Alpha']
        except Exception:
            return None

    def set_alpha(self, sock_or_val, mode):
        a = _socket(self.bsdf, 'Alpha')
        if mode == 'clip' and hasattr(sock_or_val, 'is_output') and bpy.app.version >= (4, 2, 0):
            # ab Blender 4.2 gibt es kein "Alpha Clip" mehr -> Schwelle im Node-Baum
            sock_or_val = self.math('GREATER_THAN', sock_or_val, self.fl.get('_Cutoff', 0.5))
        if hasattr(sock_or_val, 'is_output'):
            self.link(sock_or_val, a)
        else:
            a.default_value = sock_or_val
        mat = self.mat
        try:
            mat.blend_method = 'BLEND' if mode == 'blend' else 'CLIP'
            if mode == 'clip':
                mat.alpha_threshold = self.fl.get('_Cutoff', 0.5)
        except Exception:
            pass
        try:
            mat.surface_render_method = 'BLENDED' if mode == 'blend' else 'DITHERED'
        except Exception:
            pass
        try:
            mat.shadow_method = 'CLIP' if mode == 'clip' else 'HASHED'
        except Exception:
            pass
        if mode == 'blend':
            for attr in ('show_transparent_back', 'use_transparency_overlap'):   # 4.0 / 4.2+: less sorting noise
                try:
                    setattr(mat, attr, False)
                except Exception:
                    pass

    def normal_from(self, color_sock, strength=1.0):
        if color_sock is None:
            return
        nm = self.nt.nodes.new('ShaderNodeNormalMap')
        nm.location = (-250, -400)
        nm.inputs['Strength'].default_value = float(strength)
        self.link(color_sock, nm.inputs['Color'])
        self.link(nm.outputs['Normal'], _socket(self.bsdf, 'Normal'))

    def metal_rough(self, metal_sock, smooth_sock, smooth_scale=1.0):
        """Unity: Metallic = R, Glaette = A  ->  Roughness = 1 - A*Skala."""
        if metal_sock is not None:
            self.link(metal_sock, _socket(self.bsdf, 'Metallic'))
        if smooth_sock is not None:
            r = self.math('MULTIPLY_ADD', smooth_sock, -float(smooth_scale), 1.0, clamp=True)
            self.link(r, _socket(self.bsdf, 'Roughness'))

    # -- Unity Standard / VertexColor / SpeedTree
    def build_standard(self, tree=False):
        texs, fl, cols, kw = self.texs, self.fl, self.cols, self.kw
        sh = (self.d.get('shader') or '').lower()
        mt = texs.get('_MainTex') or texs.get('_MainTexture')
        main_slot = '_MainTex' if '_MainTex' in texs else ('_MainTexture' if '_MainTexture' in texs else None)
        # Standard-Shader: _MainTex_ST gilt fuer alle Maps
        st_main = (mt.get('scale', [1, 1]), mt.get('offset', [0, 0])) \
            if (mt and (sh.startswith('standard') or not sh)) else None
        base = self.tex(main_slot) if main_slot else None
        color = self.cols.get('_Color', [1, 1, 1, 1])
        albedo = base.outputs['Color'] if base else None
        if albedo is not None and color[:3] != [1, 1, 1]:
            albedo = self.mix('MULTIPLY', 1.0, albedo, color)
        # Vertexfarbe als Toenung (Virtually Live/VertexColor*)
        vc_toggle = fl.get('_VertexColor', 1.0 if ('_VERTEXCOLOR_ON' in kw or 'vl_vertexcolor' in sh) else 0.0)
        if vc_toggle > 0:
            strength = float(np.clip(VERTEX_COLOR_STRENGTH * vc_toggle, 0, 1))
            if strength > 0:
                vc = self.vertex_color()
                albedo = self.mix('MULTIPLY', strength, albedo if albedo is not None else color, vc)
        # Detail-Albedo
        det = self.tex('_DetailAlbedoMap', uv=fl.get('_UVSec', 0))
        if det is not None and albedo is not None:
            dbl = self.mix('MULTIPLY', 1.0, det.outputs['Color'], [2, 2, 2, 1])
            mask = self.tex('_DetailMask', non_color=True, st=st_main)
            albedo = self.mix('MULTIPLY', mask.outputs['Alpha'] if mask else 1.0, albedo, dbl)
        bc = _socket(self.bsdf, 'Base Color')
        if albedo is not None:
            self.link(albedo, bc)
        else:
            bc.default_value = color

        # Transparenz
        mode = fl.get('_Mode', 0)
        rtype = self.d.get('tags', {}).get('RenderType', '')
        q = self.d.get('queue', -1)
        blend = ('_ALPHABLEND_ON' in kw or '_ALPHAPREMULTIPLY_ON' in kw or mode >= 2 or
                 rtype == 'Transparent' or q >= 3000 or 'transparent' in sh)
        mname = (self.d.get('name') or '').lower()
        clip = (tree or '_ALPHATEST_ON' in kw or mode == 1 or rtype == 'TransparentCutout' or
                2450 <= q < 3000 or 'cutout' in sh or 'cutout' in mname or
                (not sh.startswith('standard') and CUTOUT_NAMES.search(mname) is not None))
        decal = bool(self.force_decal or DECAL_NAMES.search(mname) or DECAL_NAMES.search(sh))
        if decal:
            clip, blend = False, True                         # decals: texture alpha + Alpha Blend
        if blend or clip:
            alpha = base.outputs['Alpha'] if base else color[3]
            if decal and 'vertex alpha' in sh:                # Easy Decal "(Vertex Alpha)": * vertex alpha
                va = self.vertex_alpha()
                if va is not None and hasattr(alpha, 'is_output'):
                    alpha = self.math('MULTIPLY', alpha, va, clamp=True)
            if blend and '_Opacity' in fl and base is not None:
                alpha = self.math('MULTIPLY', alpha, max(fl['_Opacity'], 0.01) * 2.0, clamp=True)
            self.set_alpha(alpha, 'clip' if (clip and not blend) else 'blend')

        # Normal
        nm = self.tex('_BumpMap', non_color=True, st=st_main)
        if nm is not None:
            self.normal_from(nm.outputs['Color'], fl.get('_BumpScale', 1.0))

        # Metallic / Glaette
        mg = self.tex('_MetallicGlossMap', non_color=True, st=st_main)
        gscale = fl.get('_Smothness', fl.get('_GlossMapScale', 1.0)) if 'vertexcolor' in sh \
            else fl.get('_GlossMapScale', 1.0)
        if mg is not None:
            r, g, b = self.separate(mg.outputs['Color'])
            smooth = mg.outputs['Alpha']
            if fl.get('_SmoothnessTextureChannel', 0) >= 0.5 and base is not None:
                smooth = base.outputs['Alpha']
            self.metal_rough(r, smooth, gscale)
        else:
            _socket(self.bsdf, 'Metallic').default_value = float(np.clip(fl.get('_Metallic', 0.0), 0, 1))
            gl = fl.get('_Glossiness', 0.3 if not tree else 0.1)
            _socket(self.bsdf, 'Roughness').default_value = float(np.clip(1.0 - gl, 0.05, 1))
        if fl.get('_GlossyReflections', 1.0) < 0.5 or fl.get('_SpecularHighlights', 1.0) < 0.5:
            sp = _socket(self.bsdf, 'Specular IOR Level', 'Specular')
            if sp is not None:
                sp.default_value = 0.1

        # Emission
        em_col = cols.get('_EmissionColor', [0, 0, 0, 1])
        em = self.tex('_EmissionMap', st=st_main)
        es = _socket(self.bsdf, 'Emission Color', 'Emission')
        if '_EMISSION' in kw and es is not None and (em is not None or max(em_col[:3]) > 0):
            if em is not None:
                self.link(self.mix('MULTIPLY', 1.0, em.outputs['Color'], em_col), es)
            else:
                es.default_value = em_col
            st = _socket(self.bsdf, 'Emission Strength')
            if st is not None:
                st.default_value = 1.0

    # -- Strecken-Shader: 4 Schichten ueber Vertexfarbe (Default, R, G, B)
    def build_layered(self):
        texs, fl = self.texs, self.fl
        layers = []
        for L in ('Default', 'R', 'G', 'B'):
            if '_%sArr#0' % L in texs:                       # Texture2DArray-Variante
                bc, met, nrm = '_%sArr#0' % L, '_%sArr#1' % L, '_%sArr#2' % L
            else:
                bc, met, nrm = '_%sBC' % L, '_%sMetallic' % L, '_%sNormal' % L
            if bc not in texs:
                continue
            uv = fl.get('_%sUV' % L, 0)
            layers.append(dict(L=L, bc=bc, met=met, nrm=nrm, uv=uv,
                               nforce=fl.get('_%sNormalForce' % L, 1.0),
                               sforce=fl.get('_%sSmoothnessForce' % L, 1.0)))
        if not layers:
            return self.build_standard()
        vr, vg, vb = self.separate(self.vertex_color())
        mask = dict(R=vr, G=vg, B=vb)
        col = met = smooth = nrm = None
        for ly in layers:
            tb = self.tex(ly['bc'], uv=ly['uv'])
            tm = self.tex(ly['met'], non_color=True, uv=ly['uv'])
            tn = self.tex(ly['nrm'], non_color=True, uv=ly['uv'])
            c = tb.outputs['Color'] if tb else [0.5, 0.5, 0.5, 1]
            m = tm.outputs['Color'] if tm else [0, 0, 0, 1]
            s = tm.outputs['Alpha'] if tm else 0.2
            if tm is not None and ly['sforce'] != 1.0:
                s = self.math('MULTIPLY', s, ly['sforce'])
            n = tn.outputs['Color'] if tn else [0.5, 0.5, 1, 1]
            if tn is not None and ly['nforce'] < 0.999:      # Normalstaerke: Richtung flach mischen
                n = self.mix('MIX', float(np.clip(ly['nforce'], 0, 1)), [0.5, 0.5, 1, 1], n)
            if col is None or ly['L'] == 'Default':
                col, met, smooth, nrm = c, m, s, n
                continue
            f = mask[ly['L']]
            col = self.mix('MIX', f, col, c)
            met = self.mix('MIX', f, met, m)
            smooth = self.mix('MIX', f, smooth, s)
            nrm = self.mix('MIX', f, nrm, n)
        # Detail-Textur
        det = self.tex('_DetailBC', uv=fl.get('_DetailUV', 0))
        force = fl.get('_DetailForce', fl.get('_DefaultDetailForce', 0.0))
        if det is not None and force > 0 and hasattr(col, 'is_output'):
            dbl = self.mix('MULTIPLY', 1.0, det.outputs['Color'], [2, 2, 2, 1])
            col = self.mix('MULTIPLY', float(np.clip(force * 0.5, 0, 1)), col, dbl)
        bc = _socket(self.bsdf, 'Base Color')
        if hasattr(col, 'is_output'):
            self.link(col, bc)
        if hasattr(met, 'is_output'):
            r, g, b = self.separate(met)
            met = r
        self.metal_rough(met if hasattr(met, 'is_output') else None,
                         smooth if hasattr(smooth, 'is_output') else None)
        if hasattr(nrm, 'is_output'):
            self.normal_from(nrm, fl.get('_BumpScale', 1.0))

    # -- Distingo mesh terrain: control map (_MainTex RGBA) mixes 4 layers _Splat0-3 / _Normal0-3
    def build_splat(self):
        texs, fl = self.texs, self.fl
        mask = self.tex('_MainTex', non_color=True, st=([1, 1], [0, 0]))
        if mask is None:
            return self.build_standard()
        tiling = float(fl.get('_SplatTiling', 0) or 0)
        dt = self.d.get('distingo')
        r, g, b = self.separate(mask.outputs['Color'])
        weights = [r, g, b, mask.outputs['Alpha']]
        # Distingo normalises the mask: w / (r+g+b+a + 0.001)
        tot = self.math('ADD', self.math('ADD', r, g), self.math('ADD', b, mask.outputs['Alpha']))
        tot = self.math('ADD', tot, 0.001)
        weights = [self.math('DIVIDE', w, tot) for w in weights]

        def layer_st(slot):
            t = texs.get(slot)
            sc = list(t.get('scale', [1, 1])) if t else [1, 1]
            off = list(t.get('offset', [0, 0])) if t else [0, 0]
            if dt is not None:                       # exact: (uv*ST) * _SplatNUV * offset[N]
                i = int(slot[-1])
                k = dt['near'][i]
                su = dt['suv'][i]
                return ([sc[0] * su[0] * k, sc[1] * su[1] * k], [off[0] * su[0] * k, off[1] * su[1] * k])
            if tiling and sc == [1, 1]:
                sc = [tiling, tiling]
            return (sc, off)

        tri = dt is not None and dt['triplanar']

        col = nrm = None
        sm_terms, mt_terms = [], []
        for i in range(4):
            if tri:                                  # triplanar: world position * mult * offset[N]
                k = dt['tri_mult'] * dt['near'][i]
                tb = self.tex_box('_Splat%d' % i, k)
                tn = self.tex_box('_Normal%d' % i, k, non_color=True)
            else:
                tb = self.tex('_Splat%d' % i, st=layer_st('_Splat%d' % i))
                tn = self.tex('_Normal%d' % i, non_color=True, st=layer_st('_Normal%d' % i))
            if tb is None:
                continue
            br = dt['brightness'][i] if dt is not None else 1.0
            wc = weights[i] if abs(br - 1.0) < 1e-4 else self.math('MULTIPLY', weights[i], br)
            c = self.vmath('SCALE', tb.outputs['Color'], wc)       # colour * _Brightness[N]
            col = c if col is None else self.vmath('ADD', col, c)
            n_src = tn.outputs['Color'] if tn is not None else None
            if n_src is not None:
                k = dt['normal'][i] if dt is not None else 1.0
                if abs(k - 1.0) > 1e-4:                           # normalMod: lerp(flat, n, k)
                    n_src = self.vmath('SCALE', self.vmath('SUBTRACT', n_src, (0.5, 0.5, 1.0)), k)
                    n_src = self.vmath('ADD', n_src, (0.5, 0.5, 1.0))
                n = self.vmath('SCALE', n_src, weights[i])
                nrm = n if nrm is None else self.vmath('ADD', nrm, n)
            if dt is not None:
                for lst, acc in ((dt['smooth'], sm_terms), (dt['metal'], mt_terms)):
                    if lst[i] > 1e-4:
                        acc.append(self.math('MULTIPLY', weights[i], lst[i]))
        if col is None:
            self.link(mask.outputs['Color'], _socket(self.bsdf, 'Base Color'))
            return
        self.link(col, _socket(self.bsdf, 'Base Color'))
        if dt is not None:                                         # roughness = 1 - sum(w * smoothness)
            sm = None
            for t in sm_terms:
                sm = t if sm is None else self.math('ADD', sm, t)
            if sm is None:
                _socket(self.bsdf, 'Roughness').default_value = 1.0
            else:
                self.link(self.math('SUBTRACT', 1.0, sm, clamp=True), _socket(self.bsdf, 'Roughness'))
            mt = None
            for t in mt_terms:
                mt = t if mt is None else self.math('ADD', mt, t)
            if mt is not None:
                self.link(mt, _socket(self.bsdf, 'Metallic'))
        else:
            _socket(self.bsdf, 'Roughness').default_value = 0.85
        if nrm is not None:
            self.normal_from(nrm, 1.0)

    def vmath(self, op, a, b):
        n = self.nt.nodes.new('ShaderNodeVectorMath')
        n.operation = op
        n.location = (-500, self.y)
        self.y -= 40
        self.link(a, n.inputs[0])
        if op == 'SCALE':
            sock = _socket(n, 'Scale')
            if hasattr(b, 'is_output'):
                self.link(b, sock)
            else:
                sock.default_value = b
        elif hasattr(b, 'is_output'):
            self.link(b, n.inputs[1])
        else:
            n.inputs[1].default_value = b
        return n.outputs[0]

    # -- Wasser (AQUAS): ruhige, dunkle, glaenzende Flaeche
    def build_water(self):
        b = self.bsdf
        c = self.cols.get('_MainColor') or self.cols.get('_DeepWaterColor') or [0.06, 0.16, 0.2, 1]
        # Unity-Farben sind sRGB -> linear fuer Blender
        lin = [((v + 0.055) / 1.055) ** 2.4 if v > 0.04045 else v / 12.92 for v in c[:3]]
        _socket(b, 'Base Color').default_value = (lin[0], lin[1], lin[2], 1)
        _socket(b, 'Roughness').default_value = float(np.clip(1.0 - self.fl.get('_Gloss', 0.94), 0.02, 0.5))
        _socket(b, 'Metallic').default_value = 0.0
        # Wellen-Normalmap, falls vorhanden
        for slot in ('_MediumWavesTexture', '_LargeWavesTexture', '_SmallWavesTexture'):
            t = self.tex(slot, non_color=True)
            if t is not None:
                self.normal_from(t.outputs['Color'], 0.3)
                break


TIMING = {}


def _tick(key, t0):
    TIMING[key] = TIMING.get(key, 0.0) + (time.perf_counter() - t0)


def normals_match_smooth(V, F, N, tol=0.998):
    """True if the game normals equal Blender's own smooth normals (angle-weighted) -> custom
    normals can be skipped (expensive in Blender)."""
    if len(F) == 0:
        return True
    P = V[F]                                              # (t,3,3)
    fn = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
    ln = np.linalg.norm(fn, axis=1, keepdims=True)
    ln[ln == 0] = 1
    fn /= ln
    acc = np.zeros_like(V)
    for k in range(3):
        a = P[:, (k + 1) % 3] - P[:, k]
        b = P[:, (k + 2) % 3] - P[:, k]
        cosang = (a * b).sum(1) / np.maximum(np.linalg.norm(a, axis=1) * np.linalg.norm(b, axis=1), 1e-12)
        ang = np.arccos(np.clip(cosang, -1, 1))
        np.add.at(acc, F[:, k], fn * ang[:, None])
    la = np.linalg.norm(acc, axis=1, keepdims=True)
    la[la == 0] = 1
    acc /= la
    dots = (acc * N).sum(1)
    return bool((dots >= tol).mean() >= 0.999)


def make_blender_mesh(name, geo):
    V, F = geo['V'], geo['F']
    me = bpy.data.meshes.new(name)
    nv, nt = len(V), len(F)
    me.vertices.add(nv)
    me.vertices.foreach_set('co', V.astype(np.float32).ravel())
    me.loops.add(nt * 3)
    me.loops.foreach_set('vertex_index', F.astype(np.int32).ravel())
    me.polygons.add(nt)
    me.polygons.foreach_set('loop_start', np.arange(0, nt * 3, 3, dtype=np.int32))
    try:
        me.polygons.foreach_set('loop_total', np.full(nt, 3, np.int32))
    except Exception:
        pass          # Blender 4.x: loop_total ist read-only
    me.polygons.foreach_set('material_index', geo['mat_index'].astype(np.int32))
    me.update(calc_edges=True)

    loops = F.ravel()
    at = geo['attrs']
    uv_names = list(zip(('uv0', 'uv1', 'uv2', 'uv3'), UV_LAYER_NAMES))
    for k, nm in uv_names:
        if k in at:
            uv = me.uv_layers.new(name=nm)
            uv.data.foreach_set('uv', at[k][:, :2].astype(np.float32)[loops].ravel())
    if 'color' not in at:
        at = dict(at)
        at['color'] = np.ones((len(V), 4), np.float32)   # Unity: fehlende Vertexfarbe = Weiss
    if 'color' in at:
        c = at['color']
        if c.shape[1] == 3:
            c = np.column_stack([c, np.ones(len(c), np.float32)])
        c = c[:, :4].astype(np.float32)
        try:                                         # Rohwerte wie im Unity-Shader (Masken 0/1)
            ca = me.color_attributes.new('Col', 'FLOAT_COLOR', 'POINT')
            ca.data.foreach_set('color', c.ravel())
        except Exception:
            vc = me.vertex_colors.new(name='Col')
            vc.data.foreach_set('color', c[loops].ravel())
    if IMPORT_NORMALS and 'normal' in at:
        try:
            me.polygons.foreach_set('use_smooth', np.ones(len(me.polygons), bool))
            t0 = time.perf_counter()
            same = normals_match_smooth(V, F, at['normal'])
            _tick('normals check', t0)
            if same:
                TIMING['normals skipped'] = TIMING.get('normals skipped', 0) + 1
                return me
            t0 = time.perf_counter()
            if hasattr(me, 'use_auto_smooth'):
                me.use_auto_smooth = True
            me.normals_split_custom_set_from_vertices(at['normal'].astype(np.float32).tolist())
            _tick('custom normals', t0)
            TIMING['normals custom'] = TIMING.get('normals custom', 0) + 1
        except Exception as ex:
            print('[VLive] custom normals not set (%s): %s' % (name, ex))
    return me



EMITTER_NAMES = re.compile(r'light_?emitter|_emitter\b|emitter_|lightemitter|emission_?plane', re.I)


def is_emitter(nd, materials):
    """Leuchtkoerper-Hilfsobjekte (Boxes_light_emitter, *_emitter-Materialien)."""
    if EMITTER_NAMES.search(nd.get('name') or '') or EMITTER_NAMES.search(nd.get('mesh_name') or ''):
        return True
    mats = [materials.get(m, {}).get('name', '') for m in nd.get('materials', []) if m]
    return bool(mats) and all(EMITTER_NAMES.search(m) or 'light_emitters' in m.lower() for m in mats)


def create_paths(paths, parent_col, scene_name):
    """Fahrlinien/Boxengassen als Bezier-Kurven, Boxenplaetze als Empties."""
    if not paths:
        return 0
    col = bpy.data.collections.new('%s Racing Line' % scene_name)
    parent_col.children.link(col)
    n = 0
    for p in paths:
        pts = np.asarray(p['points'], np.float64)[:, [0, 2, 1]] * SCALE      # Unity -> Blender
        cu = bpy.data.curves.new(p['name'], 'CURVE')
        cu.dimensions = '3D'
        cu.twist_mode = 'Z_UP'
        sp = cu.splines.new('BEZIER')
        sp.bezier_points.add(len(pts) - 1)
        sp.bezier_points.foreach_set('co', pts.astype(np.float32).ravel())
        for bp in sp.bezier_points:
            bp.handle_left_type = 'AUTO'
            bp.handle_right_type = 'AUTO'
        sp.use_cyclic_u = bool(p.get('cyclic'))
        ob = bpy.data.objects.new(p['name'], cu)
        ob['vlive_type'] = p['kind']
        ob['length_m'] = round(p.get('length', 0.0), 1)
        col.objects.link(ob)
        n += 1
        if p.get('boxes'):
            bcol = bpy.data.collections.new('%s Pit Boxes' % scene_name)
            col.children.link(bcol)
            for bname, pos in p['boxes']:
                num = re.sub(r'^point_?', '', bname)
                e = bpy.data.objects.new('Box_%s' % num, None)
                e.empty_display_type = 'SINGLE_ARROW'
                e.empty_display_size = 2.0
                e.location = (pos[0] * SCALE, pos[2] * SCALE, pos[1] * SCALE)
                e['car_number'] = num
                bcol.objects.link(e)
    return n


def setup_world(path, sky, name):
    """Skybox-Panorama als Environment Texture der World."""
    if not path or not os.path.isfile(path):
        return False
    world = bpy.data.worlds.new('VLive_' + name)
    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()
    env = nt.nodes.new('ShaderNodeTexEnvironment')
    env.image = bpy.data.images.load(path, check_existing=True)
    env.location = (-600, 0)
    bg = nt.nodes.new('ShaderNodeBackground')
    bg.location = (-150, 0)
    out = nt.nodes.new('ShaderNodeOutputWorld')
    out.location = (100, 0)
    tint = sky.get('tint', [1, 1, 1])
    try:
        mul = nt.nodes.new('ShaderNodeMix')
        mul.data_type = 'RGBA'
        mul.blend_type = 'MULTIPLY'
        mul.inputs[0].default_value = 1.0
        mul.inputs[7].default_value = (tint[0], tint[1], tint[2], 1)
        mul.location = (-350, 100)
        nt.links.new(env.outputs['Color'], mul.inputs[6])
        nt.links.new(mul.outputs[2], bg.inputs['Color'])
    except Exception:
        nt.links.new(env.outputs['Color'], bg.inputs['Color'])
    bg.inputs['Strength'].default_value = float(sky.get('exposure', 1.0)) * SKY_STRENGTH
    nt.links.new(bg.outputs['Background'], out.inputs['Surface'])
    world['unity_skybox'] = sky.get('material', '')
    bpy.context.scene.world = world
    return True


def _hide_collection(col):
    """Hide in viewport + render, and exclude from the view layer (fast scene, easy to enable)."""
    col.hide_render = True
    try:
        def find(lc):
            if lc.collection == col:
                return lc
            for ch in lc.children:
                r = find(ch)
                if r:
                    return r
        lc = find(bpy.context.view_layer.layer_collection)
        if lc is not None:
            lc.exclude = True
    except Exception:
        col.hide_viewport = True


def import_scene(sd, texcache, mesh_loader, pack=False, progress=None, log=print):
    """sd = scene.SceneData. mesh_loader(ObjInfo) -> dict mit Arrays oder None."""
    matb = MaterialBuilder(texcache, sd.materials, pack=pack)
    top = bpy.data.collections.new(sd.name)
    bpy.context.scene.collection.children.link(top)
    sub_cols = {}
    mesh_data = {}
    mesh_cache = {}
    count = n_sheared = n_emit = n_inact = 0
    emit_col = inact_col = None
    inact_cols = {}
    todo = [i for i, nd in enumerate(sd.nodes) if node_filter(nd)]
    inact_names = {}
    if INACTIVE_MODE == 'HIDDEN':           # many single-object groups under one parent -> one group
        raw = {i: inactive_group(sd.nodes, i) for i in todo if is_inactive(sd.nodes[i])}
        per_parent = {}
        for g in set(raw.values()):
            per_parent.setdefault(g.split('/')[0], set()).add(g)
        for i, g in raw.items():
            head = g.split('/')[0]
            inact_names[i] = head if len(per_parent[head]) >= 6 else g
    for step, idx in enumerate(todo):
        nd = sd.nodes[idx]
        if progress and len(todo) and step % max(1, len(todo) // 10) == 0:
            progress(step / len(todo), '%s: %d%% (%d/%d objects)' % (sd.name, 100 * step // len(todo), step, len(todo)))
        sb = nd.get('static_batch')
        mats = nd.get('materials', [])
        mo = nd['mesh']
        mkey = (mo.sf.name, mo.path_id)
        Mb = np.eye(4) if sb else unity_world_to_blender(nd['world'])
        sheared = (not sb) and has_shear(Mb)
        ck = (mkey, tuple(sb) if sb else None, tuple(m or '' for m in mats)) + ((idx,) if sheared else ())
        obj_matrix = Mb
        if sheared:
            obj_matrix = np.eye(4)
            obj_matrix[:3, 3] = Mb[:3, 3]
        me = mesh_cache.get(ck)
        if me is None:
            if mkey not in mesh_data:
                t_rd = time.perf_counter()
                try:
                    mesh_data[mkey] = mesh_loader(mo)
                except Exception as ex:
                    log('  ! mesh %s unreadable: %s' % (nd.get('mesh_name'), ex))
                    mesh_data[mkey] = None
                _tick('read meshes', t_rd)
            data = mesh_data[mkey]
            if data is None:
                continue
            t_geo = time.perf_counter()
            try:
                geo = build_geometry(data, sb)
            except Exception as ex:
                log('  ! geometry %s: %s' % (nd['name'], ex))
                continue
            _tick('geometry prep', t_geo)
            if geo is None:
                continue
            if sheared:
                geo, obj_matrix = bake_matrix(geo, Mb)
                n_sheared += 1
            oname = object_name(nd, matb)
            mname = nd.get('mesh_name', '')
            t_mesh = time.perf_counter()
            me = make_blender_mesh(oname if is_generic(mname) else clean_name(mname), geo)
            _tick('blender meshes', t_mesh)
            nsub = int(geo['mat_index'].max()) + 1
            is_decal = any(DECAL_NAMES.search((x or '').lower()) for x in
                           (nd.get('name'), nd.get('mesh_name'), nd.get('path')))
            t_mat = time.perf_counter()
            for i in range(nsub):
                mk = mats[i] if i < len(mats) else (mats[-1] if mats else None)
                me.materials.append(matb.get(mk, force_decal=is_decal))
            _tick('materials', t_mat)
            mesh_cache[ck] = me
        ob = bpy.data.objects.new(object_name(nd, matb), me)
        ob.matrix_world = Matrix(obj_matrix.tolist())
        ob['unity_path'] = nd.get('path', nd['name'])
        ob['unity_gameobject'] = nd['name']
        ob['unity_mesh'] = nd.get('mesh_name', '')
        if is_emitter(nd, sd.materials):
            if emit_col is None:
                emit_col = bpy.data.collections.new('%s Light Emitters' % sd.name)
                top.children.link(emit_col)
                emit_col.hide_viewport = True
                emit_col.hide_render = True
            emit_col.objects.link(ob)
            n_emit += 1
            count += 1
            continue
        if INACTIVE_MODE == 'HIDDEN' and is_inactive(nd):
            if inact_col is None:
                inact_col = bpy.data.collections.new('%s Inactive (enabled at runtime)' % sd.name)
                top.children.link(inact_col)
            gname = inact_names.get(idx) or inactive_group(sd.nodes, idx)
            col = inact_cols.get(gname)
            if col is None:
                col = bpy.data.collections.new(gname)
                inact_col.children.link(col)
                inact_cols[gname] = col
            col.objects.link(ob)
            n_inact += 1
            count += 1
            continue
        root = clean_name(nd.get('root') or 'root')
        col = sub_cols.get(root)
        if col is None:
            col = bpy.data.collections.new(root)
            top.children.link(col)
            sub_cols[root] = col
        col.objects.link(ob)
        count += 1
        # Meshdaten freigeben, wenn kein weiterer Renderer sie braucht, ist schwer zu wissen -> am Ende
    mesh_data.clear()
    if n_emit:
        log('  %d light emitters moved to their own hidden collection' % n_emit)
    if n_inact:
        log('  %d objects that are switched off in the scene -> hidden collection "%s" (%d groups)'
            % (n_inact, inact_col.name, len(inact_cols)))
        _hide_collection(inact_col)
    sd.blender_collection = top
    return count, n_sheared
